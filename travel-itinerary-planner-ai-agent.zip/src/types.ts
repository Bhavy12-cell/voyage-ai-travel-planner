/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DestinationInfo {
  destination: string;
  bestTimeToVisit: string;
  transportTips: string;
  safetyTips: string;
  currency: string;
  photoUrl?: string;
}

export interface Activity {
  timeSlot: "Morning" | "Afternoon" | "Evening";
  name: string;
  description: string;
  estimatedCost: number;
  photoUrl?: string;
}

export interface MealRecommendation {
  type: "Breakfast" | "Lunch" | "Dinner";
  name: string;
  description: string;
  estimatedCost: number;
}

export interface DayPlan {
  dayNumber: number;
  dayTitle: string;
  activities: Activity[];
  meals: MealRecommendation[];
  costBreakdown: {
    accommodation: number;
    food: number;
    activities: number;
    transport: number;
  };
  localTips: string;
}

export interface BudgetSummary {
  totalBudget: number;
  currency: "USD" | "INR";
  actualSpent: number;
  remaining: number;
  breakdown: {
    accommodation: number;
    food: number;
    activities: number;
    transport: number;
  };
}

export interface AgentLogs {
  placesAgent: {
    thought: string;
    suggestedPlaces: string[];
    mcpLogs?: {
      tool: string;
      query?: string;
      placeId?: string;
      resultCount?: number;
      placeName?: string;
      isMock: boolean;
      details?: string;
    }[];
  };
  budgetAgent: {
    thought: string;
    allocations: {
      accommodation: number;
      food: number;
      activities: number;
      transport: number;
    };
  };
  weatherAgent?: {
    thought: string;
    forecastSummary: string;
  };
  coordinatorAgent: {
    thought: string;
    planSummary: string;
  };
}

export interface WeatherDayInfo {
  dayNumber: number;
  condition: string;
  tempMax: number;
  tempMin: number;
  icon: string;
  impactOnActivities: string;
}

export interface WeatherForecast {
  locationName: string;
  days: WeatherDayInfo[];
}

export interface Phrase {
  original: string;
  transliteration: string;
  english: string;
}

export interface LocalLanguageInfo {
  languageName: string;
  currencyCode: string;
  currencySymbol: string;
  approxConversionRate: string;
  phrases: Phrase[];
}

export interface SafetyEmergencyInfo {
  nearestHospitalGuidance: string;
  emergencyNumbers: {
    police: string;
    ambulance: string;
    fire: string;
  };
  embassyConsulateInfo?: string;
  destinationSafetyTips: string[];
}

export interface PackingItem {
  item: string;
  category: "Clothing" | "Toiletries" | "Electronics" | "Essentials" | "Other";
  reason: string;
  checked?: boolean;
}

export interface PhotoSpot {
  spotName: string;
  description: string;
  bestTime: string;
  photoTip: string;
}

export interface ItineraryResult {
  destinationInfo: DestinationInfo;
  budgetSummary: BudgetSummary;
  days: DayPlan[];
  weatherForecast?: WeatherForecast;
  localLanguageInfo?: LocalLanguageInfo;
  safetyEmergencyInfo?: SafetyEmergencyInfo;
  packingChecklist?: PackingItem[];
  bestPhotoSpots?: PhotoSpot[];
  agentLogs: AgentLogs;
}

export interface ItineraryInput {
  destination: string;
  days: number;
  budget: number;
  currency: "USD" | "INR";
  interests: string[];
  travelers: number;
}
