/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Compass,
  MapPin,
  Calendar,
  DollarSign,
  Users,
  CheckCircle,
  AlertCircle,
  Loader2,
  Sparkles,
  Utensils,
  Sun,
  Briefcase,
  Shield,
  Info,
  Layers,
  Coins,
  TrendingUp,
  RotateCcw,
  ChevronRight,
  ChevronDown,
  Check,
  Activity,
  Heart,
  Trees,
  ShoppingBag,
  Palmtree,
  Milestone,
  Languages,
  Camera,
  Download
} from "lucide-react";
import { jsPDF } from "jspdf";
import { ItineraryResult, ItineraryInput } from "./types";

// Polished Image loader component with responsive category-based fallback systems
function TravelImage({ src, alt, className }: { src?: string; alt: string; className?: string }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const handleLoad = () => setLoading(false);
  const handleError = () => {
    setLoading(false);
    setError(true);
  };

  const getClientFallbackImage = (query: string) => {
    const q = query.toLowerCase();
    if (q.includes("beach") || q.includes("sea") || q.includes("water") || q.includes("coast") || q.includes("goa") || q.includes("baga")) {
      return "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80";
    }
    if (q.includes("food") || q.includes("dinner") || q.includes("lunch") || q.includes("eat") || q.includes("restaurant") || q.includes("culinary")) {
      return "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop&q=80";
    }
    if (q.includes("fort") || q.includes("castle") || q.includes("temple") || q.includes("church") || q.includes("history") || q.includes("aguada")) {
      return "https://images.unsplash.com/photo-1590001155093-a3c66ab0c3ff?w=800&auto=format&fit=crop&q=80";
    }
    if (q.includes("market") || q.includes("shop") || q.includes("buy") || q.includes("bazaar") || q.includes("shopping") || q.includes("anjuna")) {
      return "https://images.unsplash.com/photo-1533900298318-6b8da08a523e?w=800&auto=format&fit=crop&q=80";
    }
    if (q.includes("nature") || q.includes("wildlife") || q.includes("trek") || q.includes("hiking") || q.includes("mountain")) {
      return "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&auto=format&fit=crop&q=80";
    }
    return "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&auto=format&fit=crop&q=80";
  };

  const imageSrc = error || !src ? getClientFallbackImage(alt) : src;

  return (
    <div className="relative w-full h-full overflow-hidden bg-slate-100">
      {loading && (
        <div className="absolute inset-0 bg-slate-200 animate-pulse flex items-center justify-center">
          <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
        </div>
      )}
      <img
        src={imageSrc}
        alt={alt}
        className={`${className} transition-opacity duration-500 ease-out ${loading ? "opacity-0" : "opacity-100"}`}
        onLoad={handleLoad}
        onError={handleError}
        referrerPolicy="no-referrer"
      />
    </div>
  );
}

// Static popular destination suggestions
const SUGGESTED_DESTINATIONS = [
  { name: "Tokyo, Japan", icon: "🗼", desc: "Tech, shrines & sushi" },
  { name: "Paris, France", icon: "🗼", desc: "Art, food & architecture" },
  { name: "Goa, India", icon: "🏖️", desc: "Beaches, heritage & seafood" },
  { name: "Bali, Indonesia", icon: "🌴", desc: "Temples, nature & relaxation" },
  { name: "New York, USA", icon: "🗽", desc: "Broadway, skyline & shopping" }
];

// Available interests with icons and descriptions
const INTEREST_OPTIONS = [
  { id: "adventure", label: "Adventure", icon: Milestone, desc: "Hiking, rafting, thrill activities" },
  { id: "food", label: "Food & Culinary", icon: Utensils, desc: "Local markets, fine dining, street food" },
  { id: "history", label: "History & Heritage", icon: Briefcase, desc: "Museums, ancient temples, historical sites" },
  { id: "nature", label: "Nature & Wildlife", icon: Trees, desc: "National parks, beaches, scenic views" },
  { id: "shopping", label: "Shopping", icon: ShoppingBag, desc: "Bazaars, local boutiques, premium malls" },
  { id: "relaxation", label: "Relaxation", icon: Palmtree, desc: "Spas, resort chilling, garden walks" },
  { id: "culture", label: "Culture & Art", icon: Sparkles, desc: "Theaters, art galleries, local craft" },
  { id: "nightlife", label: "Nightlife", icon: Activity, desc: "Pubs, clubs, street vibes, night shows" }
];

export default function App() {
  // User Session state
  const [user, setUser] = useState<{ email: string; name: string } | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(localStorage.getItem("voyage_auth_token"));
  const [authChecking, setAuthChecking] = useState<boolean>(true);

  // Sign In / Sign Up form state
  const [isSignUpMode, setIsSignUpMode] = useState<boolean>(false);
  const [authEmail, setAuthEmail] = useState<string>("");
  const [authPassword, setAuthPassword] = useState<string>("");
  const [authName, setAuthName] = useState<string>("");
  const [authFormError, setAuthFormError] = useState<string | null>(null);
  const [authFormLoading, setAuthFormLoading] = useState<boolean>(false);

  // Verify Session on load
  React.useEffect(() => {
    const verifySession = async () => {
      if (!authToken) {
        setAuthChecking(false);
        return;
      }
      try {
        const response = await fetch("/api/auth/me", {
          headers: {
            "Authorization": `Bearer ${authToken}`
          }
        });
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        } else {
          localStorage.removeItem("voyage_auth_token");
          setAuthToken(null);
          setUser(null);
        }
      } catch (err) {
        console.error("Failed to verify session", err);
      } finally {
        setAuthChecking(false);
      }
    };
    verifySession();
  }, [authToken]);

  // Auth Submit Handlers
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFormLoading(true);
    setAuthFormError(null);

    try {
      const response = await fetch("/api/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: authEmail, password: authPassword }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to sign in.");
      }

      localStorage.setItem("voyage_auth_token", data.token);
      setAuthToken(data.token);
      setUser(data.user);
      setAuthEmail("");
      setAuthPassword("");
    } catch (err: any) {
      setAuthFormError(err.message || "An unexpected error occurred during sign in.");
    } finally {
      setAuthFormLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFormLoading(true);
    setAuthFormError(null);

    if (!authName.trim()) {
      setAuthFormError("Please enter your name.");
      setAuthFormLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: authName, email: authEmail, password: authPassword }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to sign up.");
      }

      localStorage.setItem("voyage_auth_token", data.token);
      setAuthToken(data.token);
      setUser(data.user);
      setAuthEmail("");
      setAuthPassword("");
      setAuthName("");
    } catch (err: any) {
      setAuthFormError(err.message || "An unexpected error occurred during sign up.");
    } finally {
      setAuthFormLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${authToken}`
        }
      });
    } catch (err) {
      console.error("Logout request failed", err);
    } finally {
      localStorage.removeItem("voyage_auth_token");
      setAuthToken(null);
      setUser(null);
      setResult(null);
    }
  };

  // Input form state
  const [input, setInput] = useState<ItineraryInput>({
    destination: "",
    days: 3,
    budget: 1500,
    currency: "USD",
    interests: ["food", "nature"],
    travelers: 1
  });

  // Application flow state
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ItineraryResult | null>(null);

  // Active tab in thoughts log
  const [activeThoughtTab, setActiveThoughtTab] = useState<"places" | "budget" | "weather" | "coordinator">("places");
  // Active day index in itinerary view
  const [activeDayIndex, setActiveDayIndex] = useState<number>(0);

  // Packing Checklist interactive state
  const [packingList, setPackingList] = useState<{ item: string; category: string; reason: string; checked: boolean }[]>([]);

  // Synchronize packing checklist state with newly planned itinerary
  React.useEffect(() => {
    if (result?.packingChecklist) {
      setPackingList(result.packingChecklist);
    } else {
      setPackingList([]);
    }
  }, [result]);

  const togglePackingItem = (indexToToggle: number) => {
    setPackingList((prev) =>
      prev.map((item, i) => (i === indexToToggle ? { ...item, checked: !item.checked } : item))
    );
  };

  // PDF download state variables
  const [pdfLoading, setPdfLoading] = useState<boolean>(false);
  const [pdfSuccess, setPdfSuccess] = useState<boolean>(false);
  const [pdfError, setPdfError] = useState<string | null>(null);

  // Active section tracker for sticky quick-jump sub-header
  const [activeSection, setActiveSection] = useState<string>("overview");

  React.useEffect(() => {
    if (!result) return;
    const handleScroll = () => {
      const sections = ["overview", "itinerary", "budget", "safety", "checklist"];
      const scrollPos = window.scrollY + 160; // offset for sticky headers
      for (const section of sections) {
        const el = document.getElementById(`section-${section}`);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [result]);

  // Safe image data URL downloader with full CORS exception containment
  const getSafeImageDataUrl = async (url: string): Promise<string | null> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = url;
      img.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(img, 0, 0);
            const dataUrl = canvas.toDataURL("image/jpeg", 0.75);
            resolve(dataUrl);
            return;
          }
        } catch (e) {
          console.warn("CORS exception encountered when rendering image", e);
        }
        resolve(null);
      };
      img.onerror = () => {
        resolve(null);
      };
    });
  };

  const addWrappedText = (doc: any, text: string, x: number, y: number, maxWidth: number, lineHeight: number): number => {
    const lines = doc.splitTextToSize(text, maxWidth);
    doc.text(lines, x, y);
    return y + (lines.length * lineHeight);
  };

  // Full itinerary client-side PDF compiler using jsPDF
  const downloadFullItineraryPDF = async () => {
    if (!result) return;
    setPdfLoading(true);
    setPdfSuccess(false);
    setPdfError(null);

    try {
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4"
      });

      // Draw standard blueprint style top header and footer page markers
      const drawPageDecorations = (pageNum: number) => {
        doc.setFillColor(15, 23, 42); // slate-900 (R:15, G:23, B:42)
        doc.rect(0, 0, 210, 16, "F");
        
        doc.setTextColor(255, 255, 255);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.text("VOYAGEAI ITINERARY ORCHESTRATOR", 15, 10.5);
        
        doc.setFont("helvetica", "normal");
        doc.text(result.destinationInfo.destination.toUpperCase(), 195, 10.5, { align: "right" });

        // Divider
        doc.setDrawColor(226, 232, 240);
        doc.setLineWidth(0.25);
        doc.line(15, 280, 195, 280);

        doc.setTextColor(148, 163, 184); // slate-400
        doc.setFontSize(7.5);
        doc.text("Generated autonomously by VoyageAI Multi-Agent Planner", 15, 286);
        doc.text(`Page ${pageNum}`, 195, 286, { align: "right" });
      };

      let currentPage = 1;
      drawPageDecorations(currentPage);

      let y = 30;

      // Header Hero Block
      doc.setFillColor(248, 250, 252); // slate-50
      doc.roundedRect(15, y, 180, 50, 3, 3, "F");
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(15, y, 180, 50, 3, 3, "S");

      // Draw destination photo in header if possible
      let hasHeroImg = false;
      if (result.destinationInfo.photoUrl) {
        const heroImg = await getSafeImageDataUrl(result.destinationInfo.photoUrl);
        if (heroImg) {
          try {
            doc.addImage(heroImg, "JPEG", 20, y + 5, 55, 40);
            hasHeroImg = true;
          } catch (e) {
            console.warn("Failed drawing hero image on PDF", e);
          }
        }
      }

      const textX = hasHeroImg ? 82 : 25;
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(22);
      doc.text(result.destinationInfo.destination, textX, y + 16);

      doc.setTextColor(79, 70, 229); // indigo-600
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10.5);
      doc.text(`${result.days.length}-DAY TAILORED BLUEPRINT`, textX, y + 23);

      doc.setTextColor(100, 116, 139);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.text(`Travelers count: ${input.travelers} | Currency: ${result.budgetSummary.currency}`, textX, y + 30);
      doc.text(`Total Cost: ${result.budgetSummary.currency === "USD" ? "$" : "₹"}${result.budgetSummary.actualSpent.toLocaleString()}`, textX, y + 36);

      y += 62;

      // Section title: Overview
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.text("DESTINATION TRIP OVERVIEW", 15, y);
      y += 4;
      doc.setDrawColor(226, 232, 240);
      doc.line(15, y, 195, y);
      y += 7;

      // Best Time
      doc.setTextColor(79, 70, 229);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text("BEST TIME TO VISIT", 15, y);
      doc.setTextColor(51, 65, 85);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      y = addWrappedText(doc, result.destinationInfo.bestTimeToVisit, 15, y + 4.5, 180, 4.5);
      y += 5;

      // Transit Tips
      doc.setTextColor(79, 70, 229);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text("TRANSIT ECOSYSTEM GUIDELINE", 15, y);
      doc.setTextColor(51, 65, 85);
      doc.setFont("helvetica", "normal");
      y = addWrappedText(doc, result.destinationInfo.transportTips, 15, y + 4.5, 180, 4.5);
      y += 5;

      // Safety overview
      doc.setTextColor(79, 70, 229);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text("REGIONAL SECURITY & CULTURE HABITS", 15, y);
      doc.setTextColor(51, 65, 85);
      doc.setFont("helvetica", "normal");
      y = addWrappedText(doc, result.destinationInfo.safetyTips, 15, y + 4.5, 180, 4.5);
      y += 8;

      // Safety Emergency Console block (light crimson frame)
      doc.setFillColor(254, 242, 242);
      doc.roundedRect(15, y, 180, 32, 2, 2, "F");
      doc.setDrawColor(252, 165, 165);
      doc.roundedRect(15, y, 180, 32, 2, 2, "S");

      doc.setTextColor(153, 27, 27);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.text("EMERGENCY SAFETY CONSOLE PROTOCOL", 20, y + 6);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(127, 29, 29);
      doc.text(`Medical Center: ${result.safetyEmergencyInfo?.nearestHospitalGuidance || "Local Medical Center"}`, 20, y + 12);
      doc.text(`Regional Contact - Police: ${result.safetyEmergencyInfo?.emergencyNumbers?.police || "112 / 100"}  |  Ambulance: ${result.safetyEmergencyInfo?.emergencyNumbers?.ambulance || "112 / 102"}  |  Fire: ${result.safetyEmergencyInfo?.emergencyNumbers?.fire || "112 / 101"}`, 20, y + 18);
      
      const consStr = result.safetyEmergencyInfo?.embassyConsulateInfo || "Domestic Trip - Embassy access not required";
      doc.text(`Consular access context: ${consStr}`, 20, y + 24);

      // Day-wise Itinerary Sections
      for (const day of result.days) {
        doc.addPage();
        currentPage++;
        drawPageDecorations(currentPage);

        let dy = 25;

        // Day Title box header
        doc.setFillColor(241, 245, 249); // slate-100
        doc.roundedRect(15, dy, 180, 16, 2, 2, "F");
        doc.setDrawColor(203, 213, 225);
        doc.roundedRect(15, dy, 180, 16, 2, 2, "S");

        doc.setTextColor(15, 23, 42);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text(`DAY ${day.dayNumber} : ${day.dayTitle}`, 20, dy + 10);

        const dayCost = day.costBreakdown.accommodation + day.costBreakdown.food + day.costBreakdown.activities + day.costBreakdown.transport;
        doc.setTextColor(79, 70, 229);
        doc.setFontSize(10);
        doc.text(`Est Cost: ${result.budgetSummary.currency === "USD" ? "$" : "₹"}${dayCost.toLocaleString()}`, 190, dy + 10, { align: "right" });

        dy += 24;

        // Weather impact
        const dayWeather = result.weatherForecast?.days?.find(w => w.dayNumber === day.dayNumber);
        if (dayWeather) {
          doc.setFillColor(240, 249, 255); // light-sky
          doc.roundedRect(15, dy, 180, 12, 1.5, 1.5, "F");
          doc.setDrawColor(186, 230, 253);
          doc.roundedRect(15, dy, 180, 12, 1.5, 1.5, "S");

          doc.setTextColor(3, 105, 161);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.text(`Expected Weather: ${dayWeather.icon} ${dayWeather.condition} (${dayWeather.tempMin}°C to ${dayWeather.tempMax}°C) - ${dayWeather.impactOnActivities}`, 20, dy + 7.5);

          dy += 18;
        }

        // Timeline Header
        doc.setTextColor(15, 23, 42);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.text("CURATED DAILY ACTIVITIES", 15, dy);
        dy += 4;
        doc.setDrawColor(226, 232, 240);
        doc.line(15, dy, 195, dy);
        dy += 7;

        for (const act of day.activities) {
          // Draw standard circular timeline connector
          doc.setDrawColor(79, 70, 229);
          doc.setLineWidth(0.6);
          doc.line(19, dy - 2, 19, dy + 25);
          doc.setFillColor(79, 70, 229);
          doc.circle(19, dy + 1, 1.5, "F");

          doc.setTextColor(79, 70, 229);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.text(act.timeSlot.toUpperCase(), 24, dy + 2);

          doc.setTextColor(100, 116, 139);
          doc.text(`Estimate: ${result.budgetSummary.currency === "USD" ? "$" : "₹"}${act.estimatedCost}`, 190, dy + 2, { align: "right" });

          doc.setTextColor(15, 23, 42);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9.5);
          doc.text(act.name, 24, dy + 6.5);

          doc.setTextColor(71, 85, 105);
          doc.setFont("helvetica", "normal");
          doc.setFontSize(8.5);
          dy = addWrappedText(doc, act.description, 24, dy + 11, 162, 4);

          dy += 5;

          // Load activity image if available
          if (act.photoUrl) {
            const actImg = await getSafeImageDataUrl(act.photoUrl);
            if (actImg) {
              try {
                doc.addImage(actImg, "JPEG", 24, dy, 50, 25);
                dy += 28;
              } catch (e) {
                console.warn("Failed drawing activity photo on PDF", e);
              }
            }
          }

          dy += 4;

          if (dy > 240) {
            doc.addPage();
            currentPage++;
            drawPageDecorations(currentPage);
            dy = 25;
          }
        }

        // Dining block
        if (dy > 180) {
          doc.addPage();
          currentPage++;
          drawPageDecorations(currentPage);
          dy = 25;
        }

        doc.setTextColor(15, 23, 42);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.text("DAILY CUISINE & MEALS RECOMMENDATIONS", 15, dy);
        dy += 4;
        doc.setDrawColor(226, 232, 240);
        doc.line(15, dy, 195, dy);
        dy += 7;

        for (const meal of day.meals) {
          doc.setTextColor(79, 70, 229);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.text(meal.type.toUpperCase(), 15, dy);

          doc.setTextColor(100, 116, 139);
          doc.text(`Est Cost: ${result.budgetSummary.currency === "USD" ? "$" : "₹"}${meal.estimatedCost}`, 190, dy, { align: "right" });

          doc.setTextColor(15, 23, 42);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9);
          doc.text(meal.name, 15, dy + 4.5);

          doc.setTextColor(71, 85, 105);
          doc.setFont("helvetica", "normal");
          doc.setFontSize(8.5);
          dy = addWrappedText(doc, meal.description, 15, dy + 8.5, 175, 4);
          dy += 5;
        }

        // Daily travel hack
        if (dy > 230) {
          doc.addPage();
          currentPage++;
          drawPageDecorations(currentPage);
          dy = 25;
        }

        doc.setFillColor(240, 253, 250); // emerald-50
        doc.roundedRect(15, dy, 180, 18, 1.5, 1.5, "F");
        doc.setDrawColor(167, 243, 208);
        doc.roundedRect(15, dy, 180, 18, 1.5, 1.5, "S");

        doc.setTextColor(13, 148, 136); // teal-600
        doc.setFont("helvetica", "bold");
        doc.setFontSize(9);
        doc.text("💡 LOCAL TRAVEL HACK & DAY INSIGHT", 20, dy + 5.5);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(8.5);
        doc.setTextColor(15, 118, 110);
        addWrappedText(doc, day.localTips, 20, dy + 10.5, 170, 3.8);
      }

      // FINAL DETAILS PAGE
      doc.addPage();
      currentPage++;
      drawPageDecorations(currentPage);

      let fy = 25;

      // Budget Breakdown Table
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12.5);
      doc.text("TRIP BUDGET SHARE ANALYSIS", 15, fy);
      fy += 4;
      doc.setDrawColor(226, 232, 240);
      doc.line(15, fy, 195, fy);
      fy += 7;

      const symbol = result.budgetSummary.currency === "USD" ? "$" : "₹";
      doc.setFillColor(248, 250, 252);
      doc.rect(15, fy, 180, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(100, 116, 139);
      doc.text("CATEGORY ITEM", 20, fy + 5.5);
      doc.text("ALLOCATION BUDGET", 95, fy + 5.5);
      doc.text("CATEGORY PERCENTAGE SHARE", 145, fy + 5.5);

      fy += 8;
      const categories = [
        { name: "🏨 Accommodation & Hotel", value: result.budgetSummary.breakdown.accommodation },
        { name: "🍔 Food, Restaurants & Cafe", value: result.budgetSummary.breakdown.food },
        { name: "🎟️ Attractions & Active Activities", value: result.budgetSummary.breakdown.activities },
        { name: "🚕 Local Transit & Rides", value: result.budgetSummary.breakdown.transport }
      ];

      doc.setFont("helvetica", "normal");
      doc.setTextColor(51, 65, 85);
      for (const cat of categories) {
        doc.line(15, fy, 195, fy);
        doc.text(cat.name, 20, fy + 5.5);
        doc.text(`${symbol}${cat.value.toLocaleString()}`, 95, fy + 5.5);
        const pct = Math.round((cat.value / result.budgetSummary.actualSpent) * 100) || 0;
        doc.text(`${pct}% of actual spent`, 145, fy + 5.5);
        fy += 8;
      }

      doc.setFillColor(241, 245, 249);
      doc.rect(15, fy, 180, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.text("Total Estimated Spent", 20, fy + 5.5);
      doc.text(`${symbol}${result.budgetSummary.actualSpent.toLocaleString()}`, 95, fy + 5.5);
      doc.text("100%", 145, fy + 5.5);

      fy += 16;

      // Local linguistics details
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12.5);
      doc.text("LOCAL LANGUAGE LINGUISTICS & TRANSLATIONS", 15, fy);
      fy += 4;
      doc.setDrawColor(226, 232, 240);
      doc.line(15, fy, 195, fy);
      fy += 7;

      doc.setFillColor(248, 250, 252);
      doc.rect(15, fy, 180, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.setTextColor(100, 116, 139);
      doc.text("ENGLISH MEANING", 20, fy + 5.5);
      doc.text("LOCAL SCRIPT / WRITING", 85, fy + 5.5);
      doc.text("PHONETIC PRONUNCIATION", 145, fy + 5.5);

      fy += 8;
      doc.setFont("helvetica", "normal");
      doc.setTextColor(51, 65, 85);

      if (result.localLanguageInfo?.phrases) {
        for (const phrase of result.localLanguageInfo.phrases) {
          doc.line(15, fy, 195, fy);
          doc.text(`"${phrase.english}"`, 20, fy + 5.5);
          doc.setTextColor(79, 70, 229);
          doc.setFont("helvetica", "bold");
          doc.text(phrase.original, 85, fy + 5.5);
          doc.setFont("helvetica", "normal");
          doc.setTextColor(100, 116, 139);
          doc.text(`/${phrase.transliteration}/`, 145, fy + 5.5);
          doc.setTextColor(51, 65, 85);
          fy += 8;
        }
      }

      fy += 12;

      if (fy > 210) {
        doc.addPage();
        currentPage++;
        drawPageDecorations(currentPage);
        fy = 25;
      }

      // Packing checklist outline
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12.5);
      doc.text("SMART PACKING CHECKLIST", 15, fy);
      fy += 4;
      doc.setDrawColor(226, 232, 240);
      doc.line(15, fy, 195, fy);
      fy += 7;

      if (result.packingChecklist && result.packingChecklist.length > 0) {
        let xCol = 15;
        let originalY = fy;
        for (const item of result.packingChecklist) {
          // Check box
          doc.setDrawColor(100, 116, 139);
          doc.setLineWidth(0.3);
          doc.rect(xCol, fy, 3, 3);

          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.setTextColor(15, 23, 42);
          doc.text(item.item, xCol + 5, fy + 2.5);

          doc.setFont("helvetica", "normal");
          doc.setFontSize(7.5);
          doc.setTextColor(100, 116, 139);
          doc.text(`Category: ${item.category}`, xCol + 5, fy + 5.5);

          fy += 8.5;
          if (fy > 265) {
            if (xCol === 15) {
              xCol = 110;
              fy = originalY;
            } else {
              doc.addPage();
              currentPage++;
              drawPageDecorations(currentPage);
              fy = 25;
              originalY = 25;
              xCol = 15;
            }
          }
        }
      } else {
        doc.setTextColor(100, 116, 139);
        doc.text("No packing checklist suggested.", 15, fy);
      }

      const destNameClean = result.destinationInfo.destination.replace(/[\s,]+/g, "_");
      doc.save(`Voyage-AI-${destNameClean}-Itinerary.pdf`);
      setPdfSuccess(true);
    } catch (e: any) {
      console.error(e);
      setPdfError(e.message || "An unexpected error occurred during PDF compiling.");
    } finally {
      setPdfLoading(false);
      setTimeout(() => {
        setPdfSuccess(false);
        setPdfError(null);
      }, 3500);
    }
  };

  // High-performance canvas layout generator for printable & shareable trip summary card poster
  const downloadShareCard = () => {
    if (!result) return;
    
    const canvas = document.createElement("canvas");
    canvas.width = 1200;
    canvas.height = 675;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Draw background gradient
    const grad = ctx.createLinearGradient(0, 0, 1200, 675);
    grad.addColorStop(0, "#0f172a"); // slate-900
    grad.addColorStop(0.5, "#1e1b4b"); // indigo-950
    grad.addColorStop(1, "#311042"); // dark purple
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1200, 675);
    
    // Draw decorative blueprint grid lines
    ctx.strokeStyle = "rgba(99, 102, 241, 0.08)";
    ctx.lineWidth = 1;
    for (let i = 0; i < 1200; i += 60) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 675);
      ctx.stroke();
    }
    for (let j = 0; j < 675; j += 60) {
      ctx.beginPath();
      ctx.moveTo(0, j);
      ctx.lineTo(1200, j);
      ctx.stroke();
    }

    // Border framing
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.lineWidth = 2;
    ctx.strokeRect(30, 30, 1140, 615);
    
    // Brand signature top-left
    ctx.fillStyle = "#6366f1"; // indigo-500
    ctx.font = "bold 13px monospace";
    ctx.fillText("VOYAGEAI ITINERARY ORCHESTRATOR", 80, 80);

    // Destination Title
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 52px system-ui, -apple-system, sans-serif";
    ctx.fillText(result.destinationInfo.destination.toUpperCase(), 80, 145);
    
    // Duration and configuration info
    ctx.fillStyle = "#a5b4fc"; // indigo-300
    ctx.font = "500 18px system-ui, -apple-system, sans-serif";
    ctx.fillText(`${result.days.length}-DAY AUTOMATED JOURNEY MAP`, 80, 185);
    
    // Horizontal divider
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(80, 220);
    ctx.lineTo(1120, 220);
    ctx.stroke();

    // Left Column: Key Highlights
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 22px system-ui, -apple-system, sans-serif";
    ctx.fillText("HIGHLIGHT PLACES & ACTIVITIES", 80, 275);

    ctx.font = "17px system-ui, -apple-system, sans-serif";
    ctx.fillStyle = "#cbd5e1"; // slate-300
    const highlights: string[] = [];
    result.days.forEach(d => {
      d.activities.forEach(a => {
        if (highlights.length < 5) highlights.push(a.name);
      });
    });

    highlights.forEach((hl, idx) => {
      ctx.fillText(`•  ${hl}`, 100, 320 + (idx * 42));
    });

    // Right Column: Summary Box Background
    ctx.fillStyle = "rgba(255, 255, 255, 0.03)";
    ctx.fillRect(700, 255, 420, 290);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.lineWidth = 1;
    ctx.strokeRect(700, 255, 420, 290);

    // Estimated Budget Inside Box
    ctx.fillStyle = "#a5b4fc";
    ctx.font = "bold 13px system-ui, -apple-system, sans-serif";
    ctx.fillText("TOTAL ESTIMATED BUDGET", 740, 305);
    
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 42px system-ui, -apple-system, sans-serif";
    const symbol = result.budgetSummary.currency === "USD" ? "$" : "₹";
    ctx.fillText(`${symbol}${result.budgetSummary.actualSpent.toLocaleString()}`, 740, 355);

    // General configuration
    ctx.fillStyle = "#94a3b8";
    ctx.font = "14px system-ui, -apple-system, sans-serif";
    ctx.fillText(`Travelers Target: ${result.budgetSummary.totalBudget === 1500 ? "Solo Voyage" : `${input.travelers} Persons`}`, 740, 410);
    ctx.fillText(`Currency Code: ${result.budgetSummary.currency} (${symbol})`, 740, 440);
    ctx.fillText(`Time Generated: ${new Date().toLocaleDateString()}`, 740, 470);

    // Certified stamp
    ctx.fillStyle = "rgba(99, 102, 241, 0.2)";
    ctx.font = "bold 11px monospace";
    ctx.fillText("AUTONOMOUS MULTI-AGENT DESIGN", 740, 515);

    // Footer copyright message
    ctx.fillStyle = "rgba(255, 255, 255, 0.35)";
    ctx.font = "italic 14px system-ui, -apple-system, sans-serif";
    ctx.fillText("Designed autonomously with VoyageAI. Shared directly via custom travel suite.", 80, 595);

    // Download action
    const dataUrl = canvas.toDataURL("image/png");
    const link = document.createElement("a");
    link.download = `${result.destinationInfo.destination.replace(/[\s,]+/g, "_")}_trip_summary.png`;
    link.href = dataUrl;
    link.click();
  };

  const activeDayWeather = result?.weatherForecast?.days?.find(
    (w) => w.dayNumber === result?.days[activeDayIndex]?.dayNumber
  );

  // Interest multi-select helper
  const handleToggleInterest = (interestId: string) => {
    setInput((prev) => {
      const exists = prev.interests.includes(interestId);
      const updated = exists
        ? prev.interests.filter((id) => id !== interestId)
        : [...prev.interests, interestId];
      // Keep at least one interest selected
      return { ...prev, interests: updated.length > 0 ? updated : [interestId] };
    });
  };

  // Submit and call backend
  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.destination.trim()) {
      setError("Please specify a destination city or country.");
      return;
    }
    if (input.budget <= 0) {
      setError("Please specify a valid travel budget greater than zero.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);
    setActiveDayIndex(0);

    // Simulate agent steps in the loader to match the multi-agent timeline
    setLoadingStep(1); // Places Agent starting
    const stepIntervals = [
      setTimeout(() => setLoadingStep(2), 2000), // Budget Agent taking over
      setTimeout(() => setLoadingStep(3), 4000), // Weather Agent taking over
      setTimeout(() => setLoadingStep(4), 6500), // Coordinator synthesis
    ];

    try {
      const response = await fetch("/api/plan-itinerary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify(input)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to generate itinerary.");
      }

      const data: ItineraryResult = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during multi-agent itinerary planning.");
    } finally {
      // Clean up loader timers
      stepIntervals.forEach(clearTimeout);
      setLoading(false);
      setLoadingStep(0);
    }
  };

  // Custom pre-configured inputs loader
  const handleQuickSelect = (destName: string) => {
    setInput((prev) => ({
      ...prev,
      destination: destName,
      budget: prev.currency === "INR" ? 100000 : 1500
    }));
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Background Decorative Gradient */}
      <div className="absolute top-0 left-0 right-0 h-[400px] bg-gradient-to-b from-indigo-900/10 to-transparent pointer-events-none" />

      {/* Primary Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-indigo-600 text-white p-2.5 rounded-xl shadow-md shadow-indigo-500/20">
              <Compass className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-display tracking-tight text-slate-950 flex items-center gap-1.5">
                Voyage<span className="text-indigo-600">AI</span>
                <span className="text-[10px] font-mono tracking-wider uppercase px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 font-normal">
                  Multi-Agent v2
                </span>
              </h1>
              <p className="text-xs text-slate-500">Autonomous Travel Itinerary Orchestrator</p>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-xs">
            {user ? (
              <div className="flex items-center space-x-3 bg-slate-50 border border-slate-200 py-1.5 px-3 rounded-lg shadow-sm">
                <span className="text-slate-600 font-semibold">{user.name || user.email}</span>
                <span className="text-slate-300">|</span>
                <button
                  onClick={handleLogout}
                  className="text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2 text-slate-500">
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>Server Ready</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {authChecking ? (
        <div className="min-h-[60vh] flex flex-col items-center justify-center relative z-10">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xl p-8 max-w-sm w-full text-center space-y-4">
            <div className="inline-flex bg-indigo-50 text-indigo-600 p-4 rounded-full">
              <Compass className="w-8 h-8 animate-spin" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 font-display">Verifying session...</h2>
            <p className="text-xs text-slate-500">Checking your secure login status</p>
          </div>
        </div>
      ) : !user ? (
        <div className="max-w-md mx-auto px-4 py-16 sm:py-24 relative z-10">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xl shadow-slate-100/80 p-6 sm:p-10 space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-black tracking-tight text-slate-900 font-display uppercase">
                {isSignUpMode ? "Create Your Account" : "Sign In"}
              </h2>
              <p className="text-slate-500 text-xs">
                {isSignUpMode 
                  ? "Sign up to begin designing custom itineraries with autonomous agents" 
                  : "Sign in to plan and access your multi-agent travel blueprints"}
              </p>
            </div>

            {authFormError && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-850 flex items-start space-x-3 text-xs animate-fade-in-up">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{authFormError}</span>
              </div>
            )}

            <form onSubmit={isSignUpMode ? handleSignUp : handleSignIn} className="space-y-4">
              {isSignUpMode && (
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900"
                    placeholder="John Doe"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900"
                  placeholder="you@example.com"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                <input
                  type="password"
                  required
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900"
                  placeholder="••••••••"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                />
              </div>

              <button
                type="submit"
                disabled={authFormLoading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-bold text-xs uppercase tracking-wider py-3 px-6 rounded-xl transition-all duration-205 shadow-lg shadow-indigo-600/10 cursor-pointer flex items-center justify-center space-x-2 mt-2"
              >
                {authFormLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Please wait...</span>
                  </>
                ) : (
                  <span>{isSignUpMode ? "Create Account & Sign In" : "Sign In to Your Account"}</span>
                )}
              </button>
            </form>

            <div className="text-center pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setIsSignUpMode(!isSignUpMode);
                  setAuthFormError(null);
                  setAuthEmail("");
                  setAuthPassword("");
                  setAuthName("");
                }}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer transition-colors"
              >
                {isSignUpMode ? "Already have an account? Sign In" : "Don't have an account yet? Sign Up"}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
          {/* Error Notification */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-800 flex items-start space-x-3 animate-fade-in-up">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-sm text-red-950">Orchestration Error</p>
                <p className="text-xs text-red-800 mt-1">{error}</p>
                {error.toLowerCase().includes("limit") || error.toLowerCase().includes("quota") ? (
                  <p className="text-[11px] text-indigo-700 mt-2 font-medium">
                    Tip: The Gemini API free tier has a daily rate limit. To increase your limits, you can add your own custom Gemini API Key in the Settings &gt; Secrets menu.
                  </p>
                ) : (
                  <p className="text-[11px] text-red-600 mt-2 font-mono">
                    Hint: Check if process.env.GEMINI_API_KEY is configured correctly under Secrets in AI Studio.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Input & Form Area */}
          {!result && !loading && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in-up">
              {/* Left intro panel */}
              <div className="lg:col-span-5 flex flex-col justify-center space-y-6">
                <div className="space-y-3.5 pt-2">
                  <h2 className="text-3xl sm:text-4xl font-extrabold font-display tracking-tight text-slate-900 leading-tight">
                    Design Your Dream Journey in Seconds
                  </h2>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    VoyageAI utilizes a cooperative multi-agent architecture. The 
                    <strong className="text-indigo-600 font-medium"> Places Agent</strong> selects the finest spots based on your hobbies, the 
                    <strong className="text-indigo-600 font-medium"> Budget Agent</strong> scales costs to match your finances, and the 
                    <strong className="text-indigo-600 font-medium"> Itinerary Coordinator</strong> crafts the perfect day-by-day blueprint.
                  </p>
                </div>

              {/* Destination Badges */}
              <div className="space-y-3">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Quick Select Destinations
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {SUGGESTED_DESTINATIONS.map((dest) => (
                    <button
                      key={dest.name}
                      onClick={() => handleQuickSelect(dest.name)}
                      type="button"
                      className={`px-4 py-2 rounded-xl text-left border transition-all duration-200 cursor-pointer text-xs ${
                        input.destination === dest.name
                          ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/10"
                          : "bg-white hover:bg-slate-100 text-slate-700 border-slate-200 hover:border-slate-300"
                      }`}
                    >
                      <span className="mr-1.5">{dest.icon}</span>
                      <span className="font-semibold">{dest.name.split(",")[0]}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Cost Tier Note */}
              <div className="bg-amber-50/70 border border-amber-200/60 rounded-xl p-4 flex items-start space-x-3 text-xs text-amber-900">
                <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Smart Cost Scaling:</strong> Our Budget Agent dynamically scans cost levels based on travelers and currency parameters, adjusting accommodations from budget hostels to luxury retreats automatically.
                </p>
              </div>
            </div>

            {/* Input Form Column */}
            <div className="lg:col-span-7">
              <form
                onSubmit={handleGenerate}
                className="bg-white border border-slate-200 rounded-2xl shadow-xl shadow-slate-100/80 p-6 sm:p-8 space-y-6"
              >
                <h3 className="text-lg font-bold font-display text-slate-900 border-b border-slate-100 pb-3">
                  Travel Configuration
                </h3>

                {/* Destination */}
                <div className="space-y-2">
                  <label htmlFor="destination" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Where would you like to go?
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <input
                      id="destination"
                      type="text"
                      className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all text-slate-900 placeholder:text-slate-400"
                      placeholder="e.g., Tokyo, Bali, France, Goa..."
                      value={input.destination}
                      onChange={(e) => setInput({ ...input, destination: e.target.value })}
                      required
                    />
                  </div>
                </div>

                {/* Days & Travelers (Grid) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Duration Days */}
                  <div className="space-y-2">
                    <label htmlFor="days" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                      Trip Duration (Days)
                    </label>
                    <div className="relative">
                      <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <input
                        id="days"
                        type="number"
                        min="1"
                        max="10"
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900"
                        value={input.days}
                        onChange={(e) => setInput({ ...input, days: Math.min(10, Math.max(1, Number(e.target.value))) })}
                        required
                      />
                    </div>
                    <p className="text-[10px] text-slate-400">Max planning scope: 10 days.</p>
                  </div>

                  {/* Travelers Count */}
                  <div className="space-y-2">
                    <label htmlFor="travelers" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                      Number of Travelers
                    </label>
                    <div className="relative">
                      <Users className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <input
                        id="travelers"
                        type="number"
                        min="1"
                        max="15"
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900"
                        value={input.travelers}
                        onChange={(e) => setInput({ ...input, travelers: Math.max(1, Number(e.target.value)) })}
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Budget and Currency Section */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Currency Selection */}
                  <div className="space-y-2 sm:col-span-1">
                    <label htmlFor="currency" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                      Currency
                    </label>
                    <div className="relative">
                      <Coins className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <select
                        id="currency"
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900 appearance-none cursor-pointer"
                        value={input.currency}
                        onChange={(e) => {
                          const curr = e.target.value as "USD" | "INR";
                          setInput((prev) => ({
                            ...prev,
                            currency: curr,
                            budget: curr === "INR" ? prev.budget * 80 : Math.round(prev.budget / 80)
                          }));
                        }}
                      >
                        <option value="USD">USD ($)</option>
                        <option value="INR">INR (₹)</option>
                      </select>
                    </div>
                  </div>

                  {/* Total Budget */}
                  <div className="space-y-2 sm:col-span-2">
                    <label htmlFor="budget" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                      Total Budget ({input.currency})
                    </label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                        {input.currency === "USD" ? "$" : "₹"}
                      </span>
                      <input
                        id="budget"
                        type="number"
                        min="1"
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-xl text-sm focus:outline-none transition-all text-slate-900"
                        placeholder="e.g., 2000"
                        value={input.budget}
                        onChange={(e) => setInput({ ...input, budget: Math.max(1, Number(e.target.value)) })}
                        required
                      />
                    </div>
                    <p className="text-[10px] text-slate-400">
                      Covers entire trip expenses for {input.travelers} traveler{input.travelers > 1 ? "s" : ""}.
                    </p>
                  </div>
                </div>

                {/* Travel Interests (Checkboxes with icons) */}
                <div className="space-y-3">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Select Your Travel Interests (Choose at least one)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {INTEREST_OPTIONS.map((interest) => {
                      const Icon = interest.icon;
                      const isSelected = input.interests.includes(interest.id);
                      return (
                        <button
                          key={interest.id}
                          type="button"
                          onClick={() => handleToggleInterest(interest.id)}
                          className={`flex items-start p-3 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? "bg-indigo-50/80 border-indigo-500 ring-1 ring-indigo-500/30 text-indigo-950"
                              : "bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300"
                          }`}
                        >
                          <div
                            className={`p-1.5 rounded-lg mr-2.5 ${
                              isSelected ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-500"
                            }`}
                          >
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div className="overflow-hidden">
                            <p className="text-xs font-semibold truncate leading-tight">{interest.label}</p>
                            <p className="text-[9px] text-slate-400 truncate mt-0.5">{interest.desc}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Submit Action Button */}
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm py-3 px-6 rounded-xl transition-all duration-200 shadow-lg shadow-indigo-600/10 cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Sparkles className="w-4 h-4 text-indigo-200 animate-pulse" />
                  <span>Execute AI Multi-Agent Planner</span>
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Live Multi-Agent Execution Progress Console with layout Skeletons */}
        {loading && (
          <div className="space-y-12 my-12 animate-fade-in">
            <div className="max-w-xl mx-auto bg-white border border-slate-200 shadow-xl rounded-2xl p-6 sm:p-8 space-y-6 text-center">
              <div className="flex justify-center">
                <div className="relative">
                  <div className="absolute inset-0 bg-indigo-500/20 blur-xl rounded-full animate-pulse" />
                  <div className="relative border border-slate-150 bg-slate-50 text-indigo-600 p-4 rounded-2xl shadow-sm">
                    <Loader2 className="w-8 h-8 animate-spin" />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-bold font-display text-slate-900">
                  Orchestrating Travel Agents...
                </h3>
                <p className="text-xs text-slate-500">
                  Cooperating on specialized tasks to generate the ultimate custom journey map.
                </p>
              </div>

              {/* Agent Timeline Stepper */}
              <div className="border-t border-slate-100 pt-6 space-y-4">
                {/* Agent 1 */}
                <div className="flex items-center space-x-3.5 text-left">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                      loadingStep >= 1 ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-400"
                    }`}
                  >
                    {loadingStep > 1 ? "✓" : "1"}
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-semibold ${loadingStep >= 1 ? "text-indigo-950" : "text-slate-400"}`}>
                      Places Agent Active
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Scanning landmarks, hidden gems, and restaurants in {input.destination}...
                    </p>
                  </div>
                  {loadingStep === 1 && (
                    <span className="text-[10px] font-mono font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                      Processing
                    </span>
                  )}
                </div>

                {/* Agent 2 */}
                <div className="flex items-center space-x-3.5 text-left">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                      loadingStep >= 2 ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-400"
                    }`}
                  >
                    {loadingStep > 2 ? "✓" : "2"}
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-semibold ${loadingStep >= 2 ? "text-indigo-950" : "text-slate-400"}`}>
                      Budget Agent Active
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Allocating {input.budget} {input.currency} into accommodation, food, and transit...
                    </p>
                  </div>
                  {loadingStep === 2 && (
                    <span className="text-[10px] font-mono font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                      Processing
                    </span>
                  )}
                </div>

                {/* Agent 3 */}
                <div className="flex items-center space-x-3.5 text-left">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                      loadingStep >= 3 ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-400"
                    }`}
                  >
                    {loadingStep > 3 ? "✓" : "3"}
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-semibold ${loadingStep >= 3 ? "text-indigo-950" : "text-slate-400"}`}>
                      Weather Agent Active
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Fetching real-time local weather &amp; preparing activity indoor-outdoor safety offsets...
                    </p>
                  </div>
                  {loadingStep === 3 && (
                    <span className="text-[10px] font-mono font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                      Retrieving
                    </span>
                  )}
                </div>

                {/* Agent 4 */}
                <div className="flex items-center space-x-3.5 text-left">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                      loadingStep >= 4 ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-400"
                    }`}
                  >
                    {loadingStep > 4 ? "✓" : "4"}
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-semibold ${loadingStep >= 4 ? "text-indigo-950" : "text-slate-400"}`}>
                      Itinerary Coordinator Synthesizing
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Integrating weather alerts and budget plans into matching daily slots...
                    </p>
                  </div>
                  {loadingStep === 4 && (
                    <span className="text-[10px] font-mono font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                      Synthesizing
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Elegant empty-state layout skeleton structure */}
            <div className="space-y-12 opacity-40 select-none pointer-events-none">
              {/* Hero Banner Skeleton */}
              <div className="relative h-64 sm:h-80 w-full bg-slate-200 rounded-2xl animate-pulse flex items-end p-6 sm:p-8">
                <div className="space-y-3 w-1/2">
                  <div className="h-4 bg-slate-300 rounded w-1/4" />
                  <div className="h-8 bg-slate-300 rounded w-3/4" />
                  <div className="h-4 bg-slate-300 rounded w-full" />
                </div>
              </div>

              {/* Action Controls Skeleton */}
              <div className="h-20 bg-slate-200 rounded-xl animate-pulse" />

              {/* Overview Grid Skeleton */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="bg-white border border-slate-200 p-5 rounded-2xl animate-pulse h-24" />
                ))}
              </div>

              {/* Two Column Layout Skeleton */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-8 space-y-6">
                  <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 animate-pulse">
                    <div className="flex space-x-3 pb-4 border-b border-slate-100">
                      <div className="h-14 bg-slate-200 rounded-xl w-24" />
                      <div className="h-14 bg-slate-200 rounded-xl w-24" />
                      <div className="h-14 bg-slate-200 rounded-xl w-24" />
                    </div>
                    <div className="space-y-4">
                      <div className="h-6 bg-slate-200 rounded w-1/3" />
                      <div className="h-20 bg-slate-200 rounded-xl w-full" />
                      <div className="h-20 bg-slate-200 rounded-xl w-full" />
                    </div>
                  </div>
                </div>
                <div className="lg:col-span-4 space-y-6">
                  <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 animate-pulse">
                    <div className="h-6 bg-slate-200 rounded w-1/2" />
                    <div className="h-24 bg-slate-200 rounded-xl w-full" />
                    <div className="space-y-2">
                      <div className="h-4 bg-slate-200 rounded w-full" />
                      <div className="h-4 bg-slate-200 rounded w-5/6" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* RESULTS SCREEN */}
        {result && (
          <div className="space-y-12 animate-fade-in-up">
            {/* Destination Hero Banner */}
            <div className="relative h-64 sm:h-80 w-full rounded-2xl overflow-hidden shadow-md border border-slate-200 bg-slate-900 animate-fade-in">
              <TravelImage
                src={result.destinationInfo.photoUrl}
                alt={result.destinationInfo.destination}
                className="w-full h-full object-cover opacity-90 hover:scale-[1.02] transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex flex-col justify-end p-6 sm:p-8">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest bg-indigo-950/70 backdrop-blur-sm px-2.5 py-1 rounded-full border border-indigo-500/30 w-fit">
                  🗺️ AI Multi-Agent Planner
                </span>
                <h1 className="text-3xl sm:text-4xl font-black font-display text-white mt-2 drop-shadow-md">
                  {result.destinationInfo.destination}
                </h1>
                <p className="text-slate-200 text-xs sm:text-sm mt-1 max-w-2xl font-medium drop-shadow-sm line-clamp-2">
                  A fully customized {result.days.length}-day journey tailored to your budget and travel interests, dynamically balanced for expected climatological conditions.
                </p>
              </div>
            </div>

            {/* Action controls */}
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-white p-5 border border-slate-200 rounded-2xl shadow-sm">
              <div>
                <p className="text-xs text-slate-500 font-medium">Your Generated Itinerary for</p>
                <h2 className="text-lg font-bold font-display text-slate-900 flex items-center">
                  <MapPin className="w-4.5 h-4.5 text-indigo-600 mr-1.5" />
                  {result.destinationInfo.destination} ({result.days.length} Days)
                </h2>
              </div>
              <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
                <button
                  onClick={() => setResult(null)}
                  className="flex-1 lg:flex-initial bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs py-2.5 px-4 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 border border-slate-200"
                >
                  Edit Input Parameters
                </button>
                <button
                  onClick={() => handleGenerate()}
                  className="flex-1 lg:flex-initial bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs py-2.5 px-4 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 border border-slate-200"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                  Regenerate Variant
                </button>
                <button
                  onClick={downloadFullItineraryPDF}
                  disabled={pdfLoading}
                  className={`flex-1 lg:flex-initial font-semibold text-xs py-2.5 px-5 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md ${
                    pdfSuccess
                      ? "bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600 shadow-emerald-600/10"
                      : pdfError
                      ? "bg-red-600 hover:bg-red-700 text-white border border-red-600 shadow-red-600/10"
                      : "bg-indigo-600 hover:bg-indigo-700 text-white border border-indigo-600 shadow-indigo-600/10"
                  }`}
                >
                  {pdfLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Compiling PDF...</span>
                    </>
                  ) : pdfSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5 animate-pulse" />
                      <span>Itinerary Downloaded!</span>
                    </>
                  ) : pdfError ? (
                    <>
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Download Failed</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5 text-indigo-200 animate-bounce" />
                      <span>Download Full Itinerary as PDF</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Sticky Quick-Jump Navigation Bar */}
            <div className="sticky top-[73px] z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 py-3 px-4 -mx-4 sm:-mx-6 lg:-mx-8 flex items-center justify-center shadow-sm overflow-x-auto whitespace-nowrap scrollbar-none gap-2 sm:gap-4 transition-all duration-300">
              {[
                { id: "overview", label: "Overview", icon: Compass },
                { id: "itinerary", label: "Itinerary Plan", icon: Calendar },
                { id: "budget", label: "Budget Dashboard", icon: TrendingUp },
                { id: "safety", label: "Safety & Culture", icon: Shield },
                { id: "checklist", label: "Checklist & Photos", icon: CheckCircle },
              ].map((sec) => {
                const SecIcon = sec.icon;
                const isCurrent = activeSection === sec.id;
                return (
                  <button
                    key={sec.id}
                    onClick={() => {
                      setActiveSection(sec.id);
                      const el = document.getElementById(`section-${sec.id}`);
                      if (el) {
                        const offset = 140; // accounting for headers
                        const bodyRect = document.body.getBoundingClientRect().top;
                        const elementRect = el.getBoundingClientRect().top;
                        const elementPosition = elementRect - bodyRect;
                        const offsetPosition = elementPosition - offset;
                        window.scrollTo({
                          top: offsetPosition,
                          behavior: "smooth"
                        });
                      }
                    }}
                    className={`flex items-center space-x-1.5 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-full text-xs font-semibold tracking-wide transition-all duration-200 cursor-pointer ${
                      isCurrent
                        ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/10 scale-[1.02]"
                        : "bg-slate-50 text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-150"
                    }`}
                  >
                    <SecIcon className={`w-3.5 h-3.5 ${isCurrent ? "text-white" : "text-slate-400"}`} />
                    <span>{sec.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Destination Metadata Grid Card */}
            <div id="section-overview" className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow grid grid-cols-1 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-slate-100 scroll-mt-32">
              <div className="p-5 flex items-start space-x-3.5">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Sun className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Best Time To Visit</h4>
                  <p className="text-sm font-semibold text-slate-800 mt-1">{result.destinationInfo.bestTimeToVisit}</p>
                </div>
              </div>

              <div className="p-5 flex items-start space-x-3.5">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Transit Ecosystem</h4>
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2" title={result.destinationInfo.transportTips}>
                    {result.destinationInfo.transportTips}
                  </p>
                </div>
              </div>

              <div className="p-5 flex items-start space-x-3.5">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Safety &amp; Habits</h4>
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2" title={result.destinationInfo.safetyTips}>
                    {result.destinationInfo.safetyTips}
                  </p>
                </div>
              </div>

              <div className="p-5 flex items-start space-x-3.5 bg-indigo-50/25">
                <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Financial Context</h4>
                  <p className="text-sm font-bold text-indigo-950 mt-1">
                    Currency: {result.destinationInfo.currency}
                  </p>
                  <p className="text-[10px] text-indigo-700 font-medium">Auto-adjusted currency tier</p>
                </div>
              </div>
            </div>

            {/* DESTINATION INTELLIGENCE AGENTS (LANGUAGE & SECURITY) */}
            <div id="section-safety" className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in-up scroll-mt-32">
              {/* 1. LOCAL LANGUAGE & CURRENCY INTELLIGENCE AGENT */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100">
                        <Languages className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block leading-tight">Communication Agent</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display uppercase tracking-wider">
                          Local Language &amp; Currency
                        </h3>
                      </div>
                    </div>
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2.5 py-0.5 rounded-full border border-emerald-200 shadow-sm">
                      Conversion Agent
                    </span>
                  </div>

                  {/* Currency & Conversion info */}
                  <div className="mt-4 bg-slate-50 border border-slate-100 rounded-xl p-3.5 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Local Currency</span>
                      <p className="text-sm font-extrabold text-slate-800 mt-0.5">
                        {result.localLanguageInfo?.currencyCode || "N/A"} ({result.localLanguageInfo?.currencySymbol || ""})
                      </p>
                    </div>
                    <div className="text-right border-l border-slate-200 pl-4">
                      <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider">Approx Rate</span>
                      <p className="text-sm font-black text-indigo-950 font-mono mt-0.5">
                        {result.localLanguageInfo?.approxConversionRate || "N/A"}
                      </p>
                    </div>
                  </div>

                  {/* Basic useful phrases */}
                  <div className="mt-4 space-y-2.5">
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                      Useful Phrases ({result.localLanguageInfo?.languageName || "Local Language"})
                    </span>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-slate-100 text-[10px] font-semibold text-slate-400 text-left">
                            <th className="pb-1.5 font-semibold">English</th>
                            <th className="pb-1.5 font-semibold">Local Script/Spelling</th>
                            <th className="pb-1.5 font-semibold">Phonetic Pronunciation</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100/60">
                          {result.localLanguageInfo?.phrases && result.localLanguageInfo.phrases.length > 0 ? (
                            result.localLanguageInfo.phrases.slice(0, 6).map((phrase, i) => (
                              <tr key={i} className="text-slate-700">
                                <td className="py-2 font-medium text-slate-900">"{phrase.english}"</td>
                                <td className="py-2 text-indigo-600 font-semibold">{phrase.original}</td>
                                <td className="py-2 font-mono text-[11px] text-slate-500">/{phrase.transliteration}/</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={3} className="py-2 text-slate-400 text-center">No phrases available</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. EMERGENCY, HEALTH & SECURITY AGENT */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-red-50 text-red-600 rounded-xl border border-red-100">
                        <Shield className="w-5 h-5 text-red-500" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-red-500 uppercase tracking-widest block leading-tight">Security Agent</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display uppercase tracking-wider">
                          Safety, Health &amp; Security
                        </h3>
                      </div>
                    </div>
                    <span className="text-[10px] bg-red-50 text-red-700 font-bold px-2.5 py-0.5 rounded-full border border-red-100 shadow-sm">
                      Safety Console
                    </span>
                  </div>

                  {/* Hospital & Emergency Contacts Grid */}
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 flex flex-col justify-between">
                      <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Nearest Hospital</span>
                      <p className="text-xs font-bold text-slate-800 mt-1 line-clamp-3">
                        🏥 {result.safetyEmergencyInfo?.nearestHospitalGuidance || "Local Medical Center"}
                      </p>
                    </div>

                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 flex flex-col justify-between">
                      <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Consular Access</span>
                      <p className="text-xs font-bold text-slate-800 mt-1 line-clamp-3">
                        🏛️ {result.safetyEmergencyInfo?.embassyConsulateInfo && result.safetyEmergencyInfo.embassyConsulateInfo.toLowerCase() !== "not required" && result.safetyEmergencyInfo.embassyConsulateInfo.toLowerCase() !== "domestic trip - not required"
                          ? result.safetyEmergencyInfo.embassyConsulateInfo
                          : "Domestic Trip - Embassy access not required"}
                      </p>
                    </div>
                  </div>

                  {/* Hotlines Dial Row */}
                  <div className="mt-4 bg-red-50/40 border border-red-100/60 rounded-xl p-3">
                    <span className="text-[9px] text-red-700 font-bold uppercase tracking-wider block mb-2">Emergency Hotlines</span>
                    <div className="flex flex-wrap gap-2">
                      <span className="bg-white border border-red-100 text-red-700 px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1">
                        🚨 Police: {result.safetyEmergencyInfo?.emergencyNumbers?.police || "112 / 100"}
                      </span>
                      <span className="bg-white border border-red-100 text-red-700 px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1">
                        🚑 Ambulance: {result.safetyEmergencyInfo?.emergencyNumbers?.ambulance || "112 / 102"}
                      </span>
                      <span className="bg-white border border-red-100 text-red-700 px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1">
                        🔥 Fire: {result.safetyEmergencyInfo?.emergencyNumbers?.fire || "112 / 101"}
                      </span>
                    </div>
                  </div>

                  {/* Regional Safety Tips */}
                  <div className="mt-4 space-y-1.5">
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Destination Safety Rules</span>
                    <ul className="text-xs text-slate-600 space-y-1.5 pl-4 list-disc">
                      {result.safetyEmergencyInfo?.destinationSafetyTips && result.safetyEmergencyInfo.destinationSafetyTips.length > 0 ? (
                        result.safetyEmergencyInfo.destinationSafetyTips.slice(0, 4).map((tip, i) => (
                          <li key={i} className="leading-relaxed">
                            {tip}
                          </li>
                        ))
                      ) : (
                        <li className="text-slate-400">Keep emergency contacts handy at all times.</li>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* TWO-COLUMN RESULTS LAYOUT */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* LEFT COLUMN: ITINERARY VIEW (7 COLS) */}
              <div id="section-itinerary" className="lg:col-span-8 space-y-6 scroll-mt-32">
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  {/* Days tab headers */}
                  <div className="p-4 sm:p-5 bg-slate-50/50 border-b border-slate-200 flex gap-3 overflow-x-auto whitespace-nowrap scrollbar-none">
                    {result.days.map((day, idx) => {
                      const isActive = activeDayIndex === idx;
                      return (
                        <button
                          key={day.dayNumber}
                          onClick={() => setActiveDayIndex(idx)}
                          className={`flex-1 min-w-[100px] sm:min-w-[120px] p-3 sm:p-4 rounded-xl text-left border transition-all duration-300 cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                            isActive
                              ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/20 scale-[1.02]"
                              : "bg-white border-slate-200 hover:border-slate-300 text-slate-500 hover:text-slate-800 hover:bg-slate-50/80"
                          }`}
                        >
                          <span className={`text-[9px] font-bold uppercase tracking-widest ${isActive ? "text-indigo-200" : "text-slate-400"}`}>
                            DAY
                          </span>
                          <span className="text-lg sm:text-xl font-black font-display leading-none mt-0.5">
                            {day.dayNumber < 10 ? `0${day.dayNumber}` : day.dayNumber}
                          </span>
                          <span className={`text-[9px] font-medium truncate w-full mt-1.5 block ${isActive ? "text-indigo-100" : "text-slate-500"}`}>
                            {day.dayTitle}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Day Content panel */}
                  <div className="p-6 sm:p-8 space-y-6">
                    {/* Day Title */}
                    <div className="pb-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest flex items-center gap-1.5 flex-wrap">
                          <span>Day {result.days[activeDayIndex].dayNumber} theme</span>
                          {activeDayWeather && (
                            <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 text-[9px] font-semibold normal-case flex items-center gap-1 animate-pulse">
                              {activeDayWeather.icon} {activeDayWeather.condition} ({activeDayWeather.tempMin}°C - {activeDayWeather.tempMax}°C)
                            </span>
                          )}
                        </span>
                        <h3 className="text-xl font-bold text-slate-900 mt-1 font-display">
                          {result.days[activeDayIndex].dayTitle}
                        </h3>
                      </div>
                      <div className="bg-indigo-50 border border-indigo-100 rounded-xl px-4 py-2 text-right">
                        <span className="text-[10px] text-indigo-700 block font-medium">Estimated Day Cost</span>
                        <span className="text-sm font-bold text-indigo-950">
                          {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                          {(
                            result.days[activeDayIndex].costBreakdown.accommodation +
                            result.days[activeDayIndex].costBreakdown.food +
                            result.days[activeDayIndex].costBreakdown.activities +
                            result.days[activeDayIndex].costBreakdown.transport
                          ).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Day Weather Alert / Banner */}
                    {activeDayWeather && (
                      <div className="p-3.5 rounded-xl border border-indigo-100 bg-indigo-50/30 flex items-start gap-2.5 text-xs text-indigo-950 animate-fade-in-up">
                        <span className="text-xl leading-none mt-0.5">{activeDayWeather.icon}</span>
                        <div className="space-y-0.5">
                          <p className="font-bold flex items-center gap-1.5 text-indigo-950">
                            Expected Weather: {activeDayWeather.condition}
                            <span className="font-normal text-slate-500">({activeDayWeather.tempMin}°C to {activeDayWeather.tempMax}°C)</span>
                          </p>
                          <p className="text-slate-600 leading-relaxed text-[11px]">
                            <strong className="text-indigo-950 font-semibold">Weather Agent Plan Shift:</strong> {activeDayWeather.impactOnActivities}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Timeline Activity Loop */}
                    <div className="space-y-6 relative before:absolute before:left-3.5 before:top-4 before:bottom-4 before:w-[2px] before:bg-slate-100">
                      {result.days[activeDayIndex].activities.map((act, index) => {
                        let colorClasses = "bg-sky-50 text-sky-700 border-sky-150";
                        if (act.timeSlot === "Afternoon") {
                          colorClasses = "bg-amber-50 text-amber-700 border-amber-150";
                        } else if (act.timeSlot === "Evening") {
                          colorClasses = "bg-indigo-50 text-indigo-700 border-indigo-150";
                        }

                        return (
                          <div key={index} className="flex space-x-4 relative animate-fade-in-up">
                            {/* Dot / Indicator */}
                            <div className="z-10 w-7.5 h-7.5 rounded-full bg-white border-2 border-indigo-600 text-indigo-600 flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                              {act.timeSlot === "Morning" ? "🌅" : act.timeSlot === "Afternoon" ? "☀️" : "🌙"}
                            </div>

                            {/* Content Card with Unsplash Image Side-by-side */}
                            <div className="flex-1 bg-slate-50/50 hover:bg-slate-50 border border-slate-150 rounded-xl p-4 transition duration-200 flex flex-col md:flex-row gap-4">
                              <div className="w-full md:w-32 h-24 rounded-lg overflow-hidden border border-slate-200 shrink-0 shadow-sm bg-slate-100">
                                <TravelImage
                                  src={act.photoUrl}
                                  alt={act.name}
                                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                                />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-start justify-between gap-4">
                                  <div>
                                    <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${colorClasses}`}>
                                      {act.timeSlot}
                                    </span>
                                    <h4 className="text-sm font-bold text-slate-900 mt-2">{act.name}</h4>
                                  </div>
                                  <span className="text-xs font-semibold text-slate-500 bg-white border border-slate-200 px-2.5 py-1 rounded-lg shrink-0">
                                    {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                                    {act.estimatedCost}
                                  </span>
                                </div>
                                <p className="text-xs text-slate-600 mt-2 leading-relaxed">{act.description}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Dining and Local Eats */}
                    <div className="bg-indigo-50/40 border border-indigo-100 rounded-2xl p-5 space-y-4">
                      <div className="flex items-center space-x-2 border-b border-indigo-100/50 pb-3">
                        <Utensils className="w-4 h-4 text-indigo-600" />
                        <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-950 font-display">
                          Daily Dining &amp; Local Eats
                        </h4>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {result.days[activeDayIndex].meals.map((meal, index) => (
                          <div key={index} className="bg-white rounded-xl p-3 border border-indigo-100/60 shadow-sm space-y-1">
                            <div className="flex justify-between items-center">
                              <span className="text-[9px] font-bold text-indigo-600 uppercase tracking-widest">{meal.type}</span>
                              <span className="text-[10px] font-semibold text-slate-500">
                                {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                                {meal.estimatedCost}
                              </span>
                            </div>
                            <h5 className="text-xs font-bold text-slate-900 truncate mt-1" title={meal.name}>{meal.name}</h5>
                            <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed mt-0.5">{meal.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Day specific tip and cost division */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                      <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-4 text-emerald-950 text-xs leading-relaxed">
                        <span className="font-bold text-emerald-850 block mb-1">💡 Day travel hack</span>
                        {result.days[activeDayIndex].localTips}
                      </div>

                      {/* Micro cost breakdown progress bar */}
                      <div className="border border-slate-200 bg-white rounded-xl p-4 space-y-3.5">
                        <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                          Daily Category Breakdown
                        </span>
                        <div className="space-y-1.5">
                          {/* Accommodation */}
                          <div className="flex justify-between text-[10px]">
                            <span className="text-slate-500">Accommodation</span>
                            <span className="font-semibold text-slate-800">
                              {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                              {result.days[activeDayIndex].costBreakdown.accommodation}
                            </span>
                          </div>
                          {/* Food */}
                          <div className="flex justify-between text-[10px]">
                            <span className="text-slate-500">Food &amp; Dining</span>
                            <span className="font-semibold text-slate-800">
                              {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                              {result.days[activeDayIndex].costBreakdown.food}
                            </span>
                          </div>
                          {/* Activities */}
                          <div className="flex justify-between text-[10px]">
                            <span className="text-slate-500">Activities</span>
                            <span className="font-semibold text-slate-800">
                              {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                              {result.days[activeDayIndex].costBreakdown.activities}
                            </span>
                          </div>
                          {/* Transport */}
                          <div className="flex justify-between text-[10px]">
                            <span className="text-slate-500">Transport</span>
                            <span className="font-semibold text-slate-800">
                              {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                              {result.days[activeDayIndex].costBreakdown.transport}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN: BUDGET CHART + CONSOLE LOGS (4 COLS) */}
              <div id="section-budget" className="lg:col-span-4 space-y-6 scroll-mt-32">
                {/* 1. BUDGET SUMMARY INSTRUMENT PANEL */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 space-y-6">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100">
                        <TrendingUp className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block leading-tight">Financial Analyst</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display uppercase tracking-wider">
                          Trip Budget Dashboard
                        </h3>
                      </div>
                    </div>
                  </div>

                  {/* Summary progress circle simulation */}
                  <div className="bg-slate-50 rounded-xl p-4 space-y-4">
                    <div className="flex justify-between items-center text-xs text-slate-500">
                      <span>Total Allocation Target</span>
                      <span>Actual Estimate Cost</span>
                    </div>
                    <div className="flex items-baseline justify-between">
                      <span className="text-xs font-mono font-medium text-slate-400">
                        {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                        {result.budgetSummary.totalBudget.toLocaleString()}
                      </span>
                      <span className="text-xl font-black text-indigo-950 font-display">
                        {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                        {result.budgetSummary.actualSpent.toLocaleString()}
                      </span>
                    </div>

                    {/* Simple spending progress gauge bar */}
                    <div>
                      <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden flex">
                        <div
                          className="bg-indigo-600 h-full transition-all duration-500"
                          style={{
                            width: `${Math.min(
                              100,
                              (result.budgetSummary.actualSpent / result.budgetSummary.totalBudget) * 100
                            )}%`
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-slate-400 mt-1.5">
                        <span>Spent Progress ({Math.round((result.budgetSummary.actualSpent / result.budgetSummary.totalBudget) * 100)}%)</span>
                        {result.budgetSummary.remaining >= 0 ? (
                          <span className="text-emerald-600 font-medium font-mono">
                            Under Budget (+{result.budgetSummary.currency === "USD" ? "$" : "₹"}
                            {result.budgetSummary.remaining.toLocaleString()})
                          </span>
                        ) : (
                          <span className="text-red-500 font-medium">Over budget</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Category Breakdown Progress Meters */}
                  <div className="space-y-3.5">
                    <p className="text-xs font-semibold text-slate-700">Cost-Category Share</p>

                    {/* Accommodation */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">🏨 Accommodation</span>
                        <span className="font-semibold text-slate-800">
                          {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                          {result.budgetSummary.breakdown.accommodation.toLocaleString()}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-sky-500 h-full"
                          style={{
                            width: `${(result.budgetSummary.breakdown.accommodation / result.budgetSummary.actualSpent) * 100}%`
                          }}
                        />
                      </div>
                    </div>

                    {/* Food */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">🍔 Food &amp; Restaurants</span>
                        <span className="font-semibold text-slate-800">
                          {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                          {result.budgetSummary.breakdown.food.toLocaleString()}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-500 h-full"
                          style={{
                            width: `${(result.budgetSummary.breakdown.food / result.budgetSummary.actualSpent) * 100}%`
                          }}
                        />
                      </div>
                    </div>

                    {/* Activities */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">🎟️ Attractions &amp; Entry</span>
                        <span className="font-semibold text-slate-800">
                          {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                          {result.budgetSummary.breakdown.activities.toLocaleString()}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-500 h-full"
                          style={{
                            width: `${(result.budgetSummary.breakdown.activities / result.budgetSummary.actualSpent) * 100}%`
                          }}
                        />
                      </div>
                    </div>

                    {/* Transport */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">🚕 Local Transport</span>
                        <span className="font-semibold text-slate-800">
                          {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                          {result.budgetSummary.breakdown.transport.toLocaleString()}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full"
                          style={{
                            width: `${(result.budgetSummary.breakdown.transport / result.budgetSummary.actualSpent) * 100}%`
              }}
            />
          </div>
                    </div>
                  </div>
                </div>

                {/* 2. MULTI-AGENT THOUGHT PROCESS CONSOLE LOG */}
                <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl shadow-xl overflow-hidden flex flex-col h-[400px]">
                  {/* Console Header */}
                  <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="w-3 h-3 rounded-full bg-red-500" />
                      <span className="w-3 h-3 rounded-full bg-amber-500" />
                      <span className="w-3 h-3 rounded-full bg-emerald-500" />
                    </div>
                    <span className="text-[10px] font-mono tracking-wider text-slate-400 font-bold uppercase">
                      Agent Orchestrator Log
                    </span>
                  </div>

                  {/* Console Navigation tabs */}
                  <div className="flex border-b border-slate-800 text-xs font-mono bg-slate-950">
                    <button
                      onClick={() => setActiveThoughtTab("places")}
                      className={`flex-1 py-3 px-1 transition border-b-2 cursor-pointer ${
                        activeThoughtTab === "places"
                          ? "border-indigo-500 text-white bg-slate-900/60"
                          : "border-transparent text-slate-500 hover:text-slate-350"
                      }`}
                    >
                      PlacesAgent
                    </button>
                    <button
                      onClick={() => setActiveThoughtTab("budget")}
                      className={`flex-1 py-3 px-1 transition border-b-2 cursor-pointer ${
                        activeThoughtTab === "budget"
                          ? "border-indigo-500 text-white bg-slate-900/60"
                          : "border-transparent text-slate-500 hover:text-slate-350"
                      }`}
                    >
                      BudgetAgent
                    </button>
                    <button
                      onClick={() => setActiveThoughtTab("weather")}
                      className={`flex-1 py-3 px-1 transition border-b-2 cursor-pointer ${
                        activeThoughtTab === "weather"
                          ? "border-indigo-500 text-white bg-slate-900/60"
                          : "border-transparent text-slate-500 hover:text-slate-350"
                      }`}
                    >
                      WeatherAgent
                    </button>
                    <button
                      onClick={() => setActiveThoughtTab("coordinator")}
                      className={`flex-1 py-3 px-1 transition border-b-2 cursor-pointer ${
                        activeThoughtTab === "coordinator"
                          ? "border-indigo-500 text-white bg-slate-900/60"
                          : "border-transparent text-slate-500 hover:text-slate-350"
                      }`}
                    >
                      ItineraryCoord
                    </button>
                  </div>

                  {/* Console Log Content Area */}
                  <div className="p-4 flex-1 overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-300 space-y-4">
                    {activeThoughtTab === "places" && (
                      <div className="space-y-3.5">
                        <div className="text-emerald-400 font-bold flex items-center gap-1">
                          <span className="text-xs">▶</span> Executing PlacesAgent.scan()
                        </div>
                        <p className="whitespace-pre-wrap italic">
                          "{result.agentLogs.placesAgent.thought}"
                        </p>
                        
                        {/* Selected Landmarks */}
                        <div className="border-t border-slate-800 pt-3 space-y-1.5">
                          <p className="text-indigo-400 font-bold uppercase tracking-wider text-[10px]">
                            Selected Landmarks Selected:
                          </p>
                          <ul className="list-disc pl-4 space-y-1 text-slate-400">
                            {result.agentLogs.placesAgent.suggestedPlaces.map((place, idx) => (
                              <li key={idx}>{place}</li>
                            ))}
                          </ul>
                        </div>

                        {/* Google Places MCP Server Connections */}
                        {result.agentLogs.placesAgent.mcpLogs && result.agentLogs.placesAgent.mcpLogs.length > 0 && (
                          <div className="border-t border-slate-800 pt-3 space-y-2">
                            <p className="text-emerald-400 font-bold uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                              Google Places MCP Tool Invocations:
                            </p>
                            <div className="space-y-2 max-h-60 overflow-y-auto">
                              {result.agentLogs.placesAgent.mcpLogs.map((log, idx) => (
                                <div key={idx} className="bg-slate-950 p-2 rounded-md border border-slate-800 space-y-1 font-mono text-[10px]">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sky-400 font-bold text-[9px]">
                                      {log.tool}()
                                    </span>
                                    <span className={`px-1.5 py-0.5 rounded text-[8px] uppercase font-bold tracking-wider ${log.isMock ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'}`}>
                                      {log.isMock ? 'Simulated' : 'Real Google API'}
                                    </span>
                                  </div>
                                  {log.query && <p className="text-slate-500 text-[9px]"><span className="text-slate-400 font-bold">Query:</span> "{log.query}"</p>}
                                  {log.placeId && <p className="text-slate-500 text-[9px]"><span className="text-slate-400 font-bold">Place ID:</span> {log.placeId}</p>}
                                  <p className="text-slate-400 text-[10px] whitespace-pre-wrap">{log.details}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Free Intelligent Search and Unsplash API Notice */}
                        <div className="bg-emerald-950/25 border border-emerald-800/30 p-2.5 rounded-lg text-slate-400 text-[10px] space-y-1">
                          <p className="text-emerald-400 font-bold flex items-center gap-1.5">
                            ✨ Free Intelligent Agent Search Enabled
                          </p>
                          <p className="leading-normal font-sans text-slate-300">
                            We have completely removed the dependency on Google Maps Platform keys! The Places Agent now utilizes our serverless Free Intelligent Search (powered by Gemini) combined with the Unsplash API to fetch real physical locations, reviews, ratings, and beautiful photos entirely for free.
                          </p>
                        </div>
                      </div>
                    )}

                    {activeThoughtTab === "budget" && (
                      <div className="space-y-3.5">
                        <div className="text-emerald-400 font-bold flex items-center gap-1">
                          <span className="text-xs">▶</span> Executing BudgetAgent.calculate()
                        </div>
                        <p className="whitespace-pre-wrap italic">
                          "{result.agentLogs.budgetAgent.thought}"
                        </p>
                        <div className="border-t border-slate-800 pt-3 space-y-2">
                          <p className="text-indigo-400 font-bold uppercase tracking-wider text-[10px]">
                            Calculated Category Targets:
                          </p>
                          <div className="grid grid-cols-2 gap-2 text-slate-400">
                            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                              <span className="text-[9px] block uppercase text-slate-500">Accommodation</span>
                              <span className="font-semibold text-white">
                                {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                                {result.agentLogs.budgetAgent.allocations.accommodation}
                              </span>
                            </div>
                            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                              <span className="text-[9px] block uppercase text-slate-500">Food</span>
                              <span className="font-semibold text-white">
                                {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                                {result.agentLogs.budgetAgent.allocations.food}
                              </span>
                            </div>
                            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                              <span className="text-[9px] block uppercase text-slate-500">Activities</span>
                              <span className="font-semibold text-white">
                                {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                                {result.agentLogs.budgetAgent.allocations.activities}
                              </span>
                            </div>
                            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                              <span className="text-[9px] block uppercase text-slate-500">Transport</span>
                              <span className="font-semibold text-white">
                                {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                                {result.agentLogs.budgetAgent.allocations.transport}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeThoughtTab === "weather" && (
                      <div className="space-y-3.5">
                        <div className="text-emerald-400 font-bold flex items-center gap-1">
                          <span className="text-xs">▶</span> Executing WeatherAgent.analyze()
                        </div>
                        {result.agentLogs.weatherAgent ? (
                          <>
                            <p className="whitespace-pre-wrap italic">
                              "{result.agentLogs.weatherAgent.thought}"
                            </p>
                            <div className="border-t border-slate-800 pt-3 space-y-1.5">
                              <p className="text-indigo-400 font-bold uppercase tracking-wider text-[10px]">
                                Forecast Summary:
                              </p>
                              <span className="text-slate-400 text-xs block bg-slate-950 p-2.5 rounded-lg border border-slate-800 leading-normal">
                                {result.agentLogs.weatherAgent.forecastSummary}
                              </span>
                            </div>
                          </>
                        ) : (
                          <p className="text-slate-500 italic">No Weather Agent log found.</p>
                        )}
                      </div>
                    )}

                    {activeThoughtTab === "coordinator" && (
                      <div className="space-y-3.5">
                        <div className="text-emerald-400 font-bold flex items-center gap-1">
                          <span className="text-xs">▶</span> Executing ItineraryCoord.synthesize()
                        </div>
                        <p className="whitespace-pre-wrap italic">
                          "{result.agentLogs.coordinatorAgent.thought}"
                        </p>
                        <div className="border-t border-slate-800 pt-3">
                          <span className="text-indigo-400 font-bold uppercase tracking-wider text-[10px] block mb-1">
                            Orchestrator Completion Summary:
                          </span>
                          <span className="text-slate-400 text-xs">
                            {result.agentLogs.coordinatorAgent.planSummary}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* TRAVEL UTILITY GRID - BENTO SECTION */}
            <div id="section-checklist" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12 animate-fade-in-up scroll-mt-32">
              {/* 1. Smart Packing Checklist Agent */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100">
                        <CheckCircle className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block leading-tight">Preparation Agent</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display uppercase tracking-wider">
                          Packing Checklist
                        </h3>
                      </div>
                    </div>
                    <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2.5 py-0.5 rounded-full border border-indigo-250 shadow-sm">
                      Checklist Agent
                    </span>
                  </div>

                  {/* Checklist Completion Progress */}
                  {packingList.length > 0 && (
                    <div className="mt-4 bg-slate-50 border border-slate-100 rounded-xl p-3">
                      <div className="flex justify-between text-[10px] text-slate-500 font-bold mb-1.5">
                        <span>PREPARATION PROGRESS</span>
                        <span className="font-mono text-indigo-600">
                          {Math.round((packingList.filter(item => item.checked).length / packingList.length) * 100)}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full transition-all duration-300"
                          style={{
                            width: `${(packingList.filter(item => item.checked).length / packingList.length) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Packing items list */}
                  <div className="mt-4 space-y-2 max-h-[300px] overflow-y-auto pr-1">
                    {packingList.length > 0 ? (
                      packingList.map((item, idx) => (
                        <div
                          key={idx}
                          onClick={() => togglePackingItem(idx)}
                          className={`flex items-start p-2.5 rounded-xl border transition-all duration-150 cursor-pointer ${
                            item.checked
                              ? "bg-indigo-50/40 border-indigo-200 text-slate-500"
                              : "bg-white hover:bg-slate-50 border-slate-150 hover:border-slate-250 text-slate-850"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={!!item.checked}
                            onChange={() => {}} // handled by click container
                            className="mt-1 h-3.5 w-3.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 pointer-events-none"
                          />
                          <div className="ml-3 flex-1 min-w-0">
                            <p className={`text-xs font-semibold truncate ${item.checked ? "line-through text-slate-400 font-normal" : "text-slate-900"}`}>
                              {item.item}
                            </p>
                            <p className="text-[10px] text-slate-400 truncate leading-relaxed">
                              {item.reason}
                            </p>
                            <span className="inline-block mt-1 text-[8px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">
                              {item.category}
                            </span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400 text-xs italic text-center py-6">Checklist currently empty</p>
                    )}
                  </div>
                </div>
              </div>

              {/* 2. Best Photo Spots Agent */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-amber-50 text-amber-600 rounded-xl border border-amber-100">
                        <Camera className="w-5 h-5 text-amber-600" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-amber-500 uppercase tracking-widest block leading-tight">Scenic Guide</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display uppercase tracking-wider">
                          Best Photo Spots
                        </h3>
                      </div>
                    </div>
                    <span className="text-[10px] bg-amber-50 text-amber-700 font-bold px-2.5 py-0.5 rounded-full border border-amber-200 shadow-sm">
                      Scenic Agent
                    </span>
                  </div>

                  {/* Photo Spots list */}
                  <div className="mt-4 space-y-3 max-h-[380px] overflow-y-auto pr-1">
                    {result.bestPhotoSpots && result.bestPhotoSpots.length > 0 ? (
                      result.bestPhotoSpots.map((spot, idx) => (
                        <div key={idx} className="bg-slate-50/50 hover:bg-indigo-50/30 border border-slate-150 rounded-xl p-3.5 transition-all duration-200">
                          <div className="flex items-start justify-between">
                            <h4 className="text-xs font-bold text-slate-900 leading-tight">
                              📸 {spot.spotName}
                            </h4>
                            <span className="text-[8px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded bg-amber-100 text-amber-800 shrink-0 font-mono">
                              {spot.bestTimeToVisit}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-600 mt-1.5 leading-relaxed">
                            {spot.description}
                          </p>
                          <div className="mt-2 text-[9px] bg-white border border-slate-100 rounded-lg p-2 text-indigo-950 font-medium leading-normal italic">
                            <span className="font-bold not-italic text-indigo-700">Photo tip:</span> {spot.photoTip}
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400 text-xs italic text-center py-6">No curated photo spots found</p>
                    )}
                  </div>
                </div>
              </div>

              {/* 3. Trip Summary Share Card */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100">
                        <Sparkles className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block leading-tight">Design Studio</span>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display uppercase tracking-wider">
                          Trip Summary Poster
                        </h3>
                      </div>
                    </div>
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2.5 py-0.5 rounded-full border border-emerald-200 shadow-sm">
                      Shareable Card
                    </span>
                  </div>

                  {/* Share Poster Preview */}
                  <div className="mt-4 bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 text-white rounded-xl p-5 border border-indigo-800 shadow-lg relative overflow-hidden aspect-[16/9] flex flex-col justify-between">
                    <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />
                    
                    <div>
                      <span className="text-[8px] font-mono tracking-widest text-indigo-300 uppercase block">
                        VoyageAI Trip Poster
                      </span>
                      <h4 className="text-base font-black font-display uppercase tracking-tight mt-1 truncate">
                        {result.destinationInfo.destination}
                      </h4>
                      <p className="text-[9px] text-slate-300 mt-0.5 font-medium">
                        Customized {result.days.length}-Day Autonomous Blueprint
                      </p>
                    </div>

                    <div className="flex items-end justify-between">
                      <div>
                        <span className="text-[8px] text-slate-400 uppercase tracking-widest block">HIGHLIGHT LANDMARK</span>
                        <p className="text-[9px] font-semibold text-indigo-200 truncate max-w-[150px]">
                          {result.days[0]?.activities[0]?.name || "Local Landmark"}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="text-[8px] text-indigo-300 uppercase tracking-widest block font-bold">EST BUDGET</span>
                        <p className="text-sm font-black text-white font-display">
                          {result.budgetSummary.currency === "USD" ? "$" : "₹"}
                          {result.budgetSummary.actualSpent.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 leading-normal mt-3">
                    Generate an Instagram-ready high-resolution digital summary card poster. Instantly save it to your local device and share your complete custom voyage with friends or on social media.
                  </p>
                </div>

                <div className="mt-4">
                  <button
                    onClick={downloadShareCard}
                    className="w-full bg-slate-950 hover:bg-slate-850 text-white font-semibold text-xs py-2.5 px-4 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-slate-900/10 border border-slate-800"
                  >
                    <Download className="w-4 h-4 text-indigo-400 animate-bounce" />
                    <span>Download HD Poster Card</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 mt-16 text-xs text-slate-500 text-center">
        <p className="mb-2">© 2026 VoyageAI Travel Itinerary Orchestrator.</p>
        <p>Built as a multi-agent system combining Places Agent, Budget Agent, and Itinerary Coordinator Agent.</p>
      </footer>
    </div>
  );
}
