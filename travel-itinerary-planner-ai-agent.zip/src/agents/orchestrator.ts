/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { ItineraryInput, ItineraryResult } from "../types.js";
import { searchPlacesMcp, getPlaceDetailsMcp, fetchUnsplashPhoto } from "./mcpPlacesClient.js";

// Lazy initialization of the Gemini SDK Client to handle missing key gracefully
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error(
        "GEMINI_API_KEY environment variable is required. Please set it in Settings > Secrets."
      );
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

/**
 * Fetches real live weather data from Open-Meteo public APIs without requiring API keys.
 * Resolves latitude and longitude from destination name first.
 */
async function fetchRealWeather(destination: string, days: number) {
  try {
    console.log(`[Weather Agent API] Resolving coordinates for: ${destination}`);
    // 1. Geocode lookup using Open-Meteo Geocoding API
    const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(destination)}&count=1&language=en&format=json`;
    const geoRes = await fetch(geoUrl);
    if (!geoRes.ok) {
      console.warn(`[Weather Agent API] Geocoding API failed: ${geoRes.status}`);
      return null;
    }
    const geoData = await geoRes.json();
    if (!geoData.results || geoData.results.length === 0) {
      console.warn(`[Weather Agent API] No location found for: ${destination}`);
      return null;
    }

    const loc = geoData.results[0];
    const lat = loc.latitude;
    const lon = loc.longitude;
    const resolvedName = `${loc.name}, ${loc.country}`;
    console.log(`[Weather Agent API] Resolved to: ${resolvedName} (${lat}, ${lon})`);

    // 2. Fetch daily weather from Open-Meteo Forecast API
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto`;
    const weatherRes = await fetch(weatherUrl);
    if (!weatherRes.ok) {
      console.warn(`[Weather Agent API] Forecast API failed: ${weatherRes.status}`);
      return null;
    }
    const weatherData = await weatherRes.json();
    if (!weatherData.daily) {
      console.warn(`[Weather Agent API] No daily data returned from Open-Meteo`);
      return null;
    }

    const daily = weatherData.daily;
    const weatherDays = [];

    // Map WMO weather codes to human-readable condition string and appropriate emoji
    const getWeatherCondition = (code: number): { condition: string; icon: string } => {
      if (code === 0) return { condition: "Sunny", icon: "☀️" };
      if (code >= 1 && code <= 3) return { condition: "Partly Cloudy", icon: "🌤️" };
      if (code === 45 || code === 48) return { condition: "Foggy", icon: "🌫️" };
      if (code >= 51 && code <= 55) return { condition: "Drizzle", icon: "🌧️" };
      if (code >= 56 && code <= 57) return { condition: "Freezing Drizzle", icon: "🌧️" };
      if (code >= 61 && code <= 65) return { condition: "Rainy", icon: "🌧️" };
      if (code >= 66 && code <= 67) return { condition: "Freezing Rain", icon: "🌧️" };
      if (code >= 71 && code <= 77) return { condition: "Snowy", icon: "❄️" };
      if (code >= 80 && code <= 82) return { condition: "Rain Showers", icon: "🌧️" };
      if (code >= 85 && code <= 86) return { condition: "Snow Showers", icon: "❄️" };
      if (code >= 95 && code <= 99) return { condition: "Thunderstorm", icon: "⛈️" };
      return { condition: "Cloudy", icon: "☁️" };
    };

    // Construct the days Array
    for (let i = 0; i < days; i++) {
      const idx = i % daily.time.length;
      const code = daily.weather_code ? daily.weather_code[idx] : 0;
      const tMax = daily.temperature_2m_max ? daily.temperature_2m_max[idx] : 22;
      const tMin = daily.temperature_2m_min ? daily.temperature_2m_min[idx] : 15;

      const { condition, icon } = getWeatherCondition(code);
      weatherDays.push({
        dayNumber: i + 1,
        condition,
        tempMax: Math.round(tMax),
        tempMin: Math.round(tMin),
        icon,
      });
    }

    return {
      locationName: resolvedName,
      weatherDays,
    };
  } catch (err) {
    console.warn(`[Weather Agent API] Error fetching live weather:`, err);
    return null;
  }
}

/**
 * Run the Multi-Agent Travel Planner Orchestration.
 *
 * This process executes four consecutive agents:
 * 1. Places Agent — suggests attractions based on destination and interests
 * 2. Budget Agent — calculates and allocates costs across categories
 * 3. Weather Agent — retrieves/predicts weather forecast and advises on indoor/outdoor suitability
 * 4. Itinerary Coordinator Agent — synthesizes everything, matching day layouts to the weather forecast
 */
export async function runOrchestrator(
  input: ItineraryInput
): Promise<ItineraryResult> {
  const ai = getAiClient();
  const modelName = "gemini-3.5-flash";

  console.log(`[Orchestrator] Executing optimized Multi-Agent Cooperative Suite for: ${input.destination}`);

  // Fetch real-time weather coordinates & daily forecast
  const liveWeather = await fetchRealWeather(input.destination, input.days);

  // Query Google Places MCP directly via backend code to get actual locations (saves 1-2 Gemini turns!)
  const mcpLogs: any[] = [];
  let suggestedBasePlaces: string[] = [];
  try {
    console.log(`[Orchestrator] Direct-querying Google Places MCP for landmarks in: ${input.destination}`);
    const { places, isMock } = await searchPlacesMcp(input.destination);
    if (places && places.length > 0) {
      suggestedBasePlaces = places.map(
        (p) => `${p.name} (Rating: ★${p.rating || "N/A"}, reviews: ${p.userRatingCount || 0}, Address: ${p.address || "N/A"})`
      );
      mcpLogs.push({
        tool: "google_maps_search_places",
        query: input.destination,
        resultCount: places.length,
        isMock,
        details: `Successfully retrieved real-world landmarks: ${places.map(p => `${p.name} (★${p.rating || "N/A"})`).join(", ")}`,
      });
    }
  } catch (err) {
    console.warn("[Orchestrator] Direct Places MCP query failed, will rely on LLM fallback:", err);
  }

  // Combine Budget, Weather, and Coordinator roles into a single Cooperative Suite prompt
  const coordinatorPrompt = `
    You are an elite AI Travel Orchestration Suite comprising 6 highly cooperative agents:
    1. Places Agent — suggests tourist attractions, scenic spots, and local culinary experiences.
    2. Budget Agent — calculates realistic expenses, divides budgets, and manages costs.
    3. Weather Agent — climatologist who analyzes weather conditions and defines outdoor/indoor planning constraints.
    4. Packing Checklist Agent — generates a highly personalized, smart packing checklist based on the destination's weather, trip duration, and planned activities.
    5. Best Photo Spots Agent — suggests 3-4 highly scenic, Instagram-worthy photo locations at the destination with custom tips on best lighting and best times of day to visit.
    6. Itinerary Coordinator Agent — master scheduler who synthesizes places, budget, and weather into a cohesive daily timeline.

    Your task is to execute all of these agent roles cooperatively in a single step to build a seamless, premium travel plan for:
    - Destination: ${input.destination}
    - Duration: ${input.days} Days
    - Budget: ${input.budget} ${input.currency}
    - Travelers: ${input.travelers}
    - Selected Interests: ${input.interests.join(", ")}

    COOPERATIVE INPUT DATA:
    - Real-world landmarks retrieved: ${JSON.stringify(suggestedBasePlaces)}
    - Live Weather retrieved: ${liveWeather ? JSON.stringify(liveWeather) : "No live weather feed (climatologically predict typical July conditions)"}

    ROLES & CRITICAL INSTRUCTIONS:

    [Places Agent Role]
    - Analyze the gathered landmarks and recommend 8 to 12 attractions. For each, synthesize details (ratings, review counts, open hours, and positive highlights).
    - Provide 4 to 6 local specialties, dishes, or food spots.

    [Budget Agent Role]
    - Allocate the total budget of ${input.budget} ${input.currency} across four core categories (Accommodation, Food, Activities, Transport).
    - Scale costs to fit traveler count (${input.travelers}), days (${input.days}), and destination cost-of-living.
    - Sum of categories MUST be equal to or slightly less than the total budget. Express allocations in ${input.currency}.

    [Weather Agent Role]
    - Examine the Live Weather. If live weather is not available, historically predict typical July weather for ${input.destination} with variety (e.g. at least one rainy or cloudy day to test and display our indoor-outdoor adaptation mechanism).
    - Supply a short forecast summary and an array of day-by-day forecasts detailing condition, max/min temperatures (Celsius), weather icon emoji, and an active impact statement (e.g., 'Predicted heavy rain; schedule indoor museums/covered markets today.').

    [Packing Checklist Agent Role]
    - Generate a smart, custom packing list tailored to the destination, forecast, and activities.
    - Provide 8-12 packing items divided into categories: 'Clothing', 'Toiletries', 'Electronics', 'Essentials', 'Other'.
    - For each item, specify a friendly, highly specific reason (e.g., 'Since trekking is in the itinerary, sturdy shoes are essential', 'Pack a compact umbrella as a rainy shift is forecast for Day 2').

    [Best Photo Spots Agent Role]
    - Recommend 3 to 4 photogenic or Instagram-worthy spots at the destination.
    - For each spot, specify the location/spot name, description, the best time of day for premium lighting (e.g., 'Golden Hour / 5:30 PM', 'Early Morning / 6:30 AM before crowds'), and a professional photography tip.

    [Itinerary Coordinator Agent Role]
    - Synthesize places, budget, and weather into a beautiful, logical day-by-day schedule.
    - RIGIDLY RESPECT THE WEATHER:
      * On Rainy/Thunderstorm/Sleet days, schedule indoor/covered attractions (museums, indoor markets, restaurants, art galleries, cooking schools, craft workshops) instead of beaches, parks, viewpoints, or open-air walking tours.
      * On Sunny/Partly Cloudy days, schedule outdoor activities (beaches, parks, hiking, outdoor markets, historical forts).
    - Each day must include:
      * Day Title (e.g. 'Historic Explorations [Rainy Weather Shift]' or 'Sunny Beachfront Hikes')
      * Morning, Afternoon, Evening activities (with descriptions and realistic cost tags in ${input.currency})
      * Breakfast, Lunch, Dinner recommendations (culinary spots aligned with interests)
      * Daily cost breakdown (accommodation, food, activities, transport)
      * Practical local tips or rain/sun survival hacks for that day

    [Local Language & Currency Section]
    - Identify the primary local language.
    - Identify the local currency and its approximate exchange rate to ${input.currency} (Format: "1 ${input.currency} ≈ X Local" or "1 Local ≈ Y ${input.currency}").
    - Provide 5-6 common phrases (e.g., 'Hello', 'Thank you', 'How much does this cost?', 'Where is the bathroom?', 'Help') with original local script, phonetic transliteration, and English translation.

    [Safety & Emergency Section]
    - Give a named real-world hospital or medical center in ${input.destination} or regional medical guidance.
    - Provide local emergency contact phone numbers for Police, Ambulance, and Fire in that specific country.
    - Provide nearest embassy or consulate info if the trip is international (different country from ${input.currency === "INR" ? "India" : "United States"}). If it is a domestic destination, output "Domestic Trip - Not required".
    - Give 3-4 highly specific safety tips for this destination.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: coordinatorPrompt,
      config: {
        systemInstruction:
          "You are the Cooperative Multi-Agent Suite. You simulate the expertise of Places, Budget, Weather, Packing, Photo Spots, and Coordinator agents to generate a perfectly coordinated travel itinerary JSON.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            placesAgentThought: { type: Type.STRING },
            placesAgentSuggestedPlaces: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            placesAgentLocalSpecialties: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            budgetAgentThought: { type: Type.STRING },
            budgetAgentAllocations: {
              type: Type.OBJECT,
              properties: {
                accommodation: { type: Type.NUMBER },
                food: { type: Type.NUMBER },
                activities: { type: Type.NUMBER },
                transport: { type: Type.NUMBER },
              },
              required: ["accommodation", "food", "activities", "transport"],
            },
            weatherAgentThought: { type: Type.STRING },
            weatherAgentForecastSummary: { type: Type.STRING },
            weatherAgentDays: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  condition: { type: Type.STRING },
                  tempMax: { type: Type.NUMBER },
                  tempMin: { type: Type.NUMBER },
                  icon: { type: Type.STRING },
                  impactOnActivities: { type: Type.STRING },
                },
                required: ["dayNumber", "condition", "tempMax", "tempMin", "icon", "impactOnActivities"],
              },
            },
            packingChecklist: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  item: { type: Type.STRING },
                  category: { type: Type.STRING, description: "Must be 'Clothing', 'Toiletries', 'Electronics', 'Essentials', or 'Other'" },
                  reason: { type: Type.STRING },
                },
                required: ["item", "category", "reason"],
              },
            },
            bestPhotoSpots: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  spotName: { type: Type.STRING },
                  description: { type: Type.STRING },
                  bestTime: { type: Type.STRING },
                  photoTip: { type: Type.STRING },
                },
                required: ["spotName", "description", "bestTime", "photoTip"],
              },
            },
            destinationInfo: {
              type: Type.OBJECT,
              properties: {
                destination: { type: Type.STRING },
                bestTimeToVisit: { type: Type.STRING },
                transportTips: { type: Type.STRING },
                safetyTips: { type: Type.STRING },
                currency: { type: Type.STRING },
              },
              required: ["destination", "bestTimeToVisit", "transportTips", "safetyTips", "currency"],
            },
            budgetSummary: {
              type: Type.OBJECT,
              properties: {
                totalBudget: { type: Type.NUMBER },
                currency: { type: Type.STRING },
                actualSpent: { type: Type.NUMBER },
                remaining: { type: Type.NUMBER },
                breakdown: {
                  type: Type.OBJECT,
                  properties: {
                    accommodation: { type: Type.NUMBER },
                    food: { type: Type.NUMBER },
                    activities: { type: Type.NUMBER },
                    transport: { type: Type.NUMBER },
                  },
                  required: ["accommodation", "food", "activities", "transport"],
                },
              },
              required: ["totalBudget", "currency", "actualSpent", "remaining", "breakdown"],
            },
            days: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  dayTitle: { type: Type.STRING },
                  activities: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        timeSlot: { type: Type.STRING },
                        name: { type: Type.STRING },
                        description: { type: Type.STRING },
                        estimatedCost: { type: Type.NUMBER },
                      },
                      required: ["timeSlot", "name", "description", "estimatedCost"],
                    },
                  },
                  meals: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        type: { type: Type.STRING },
                        name: { type: Type.STRING },
                        description: { type: Type.STRING },
                        estimatedCost: { type: Type.NUMBER },
                      },
                      required: ["type", "name", "description", "estimatedCost"],
                    },
                  },
                  costBreakdown: {
                    type: Type.OBJECT,
                    properties: {
                      accommodation: { type: Type.NUMBER },
                      food: { type: Type.NUMBER },
                      activities: { type: Type.NUMBER },
                      transport: { type: Type.NUMBER },
                    },
                    required: ["accommodation", "food", "activities", "transport"],
                  },
                  localTips: { type: Type.STRING },
                },
                required: ["dayNumber", "dayTitle", "activities", "meals", "costBreakdown", "localTips"],
              },
            },
            localLanguageInfo: {
              type: Type.OBJECT,
              properties: {
                languageName: { type: Type.STRING },
                currencyCode: { type: Type.STRING },
                currencySymbol: { type: Type.STRING },
                approxConversionRate: { type: Type.STRING },
                phrases: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      original: { type: Type.STRING },
                      transliteration: { type: Type.STRING },
                      english: { type: Type.STRING },
                    },
                    required: ["original", "transliteration", "english"],
                  },
                },
              },
              required: ["languageName", "currencyCode", "currencySymbol", "approxConversionRate", "phrases"],
            },
            safetyEmergencyInfo: {
              type: Type.OBJECT,
              properties: {
                nearestHospitalGuidance: { type: Type.STRING },
                emergencyNumbers: {
                  type: Type.OBJECT,
                  properties: {
                    police: { type: Type.STRING },
                    ambulance: { type: Type.STRING },
                    fire: { type: Type.STRING },
                  },
                  required: ["police", "ambulance", "fire"],
                },
                embassyConsulateInfo: { type: Type.STRING },
                destinationSafetyTips: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ["nearestHospitalGuidance", "emergencyNumbers", "embassyConsulateInfo", "destinationSafetyTips"],
            },
            coordinatorThought: { type: Type.STRING },
          },
          required: [
            "placesAgentThought",
            "placesAgentSuggestedPlaces",
            "placesAgentLocalSpecialties",
            "budgetAgentThought",
            "budgetAgentAllocations",
            "weatherAgentThought",
            "weatherAgentForecastSummary",
            "weatherAgentDays",
            "packingChecklist",
            "bestPhotoSpots",
            "destinationInfo",
            "budgetSummary",
            "days",
            "localLanguageInfo",
            "safetyEmergencyInfo",
            "coordinatorThought",
          ],
        },
      },
    });

    const finalData = JSON.parse(response.text.trim());

    // Fetch primary hero photo for destination using Unsplash with robust try-catch
    console.log(`[Orchestrator] Fetching hero photo from Unsplash for: "${input.destination}"`);
    let destinationPhotoUrl = "";
    try {
      destinationPhotoUrl = await fetchUnsplashPhoto(input.destination);
    } catch (e) {
      console.warn(`[Orchestrator] Error fetching hero photo for ${input.destination}:`, e);
      destinationPhotoUrl = "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&auto=format&fit=crop";
    }

    if (finalData.destinationInfo) {
      finalData.destinationInfo.photoUrl = destinationPhotoUrl;
    }

    // Fetch individual Unsplash photos for each activity in parallel with isolated try-catches
    console.log("[Orchestrator] Fetching unique Unsplash photos for each daily activity card...");
    let daysWithPhotos = finalData.days || [];
    try {
      daysWithPhotos = await Promise.all(
        (finalData.days || []).map(async (day: any) => {
          const activitiesWithPhotos = await Promise.all(
            (day.activities || []).map(async (act: any) => {
              let actPhotoUrl = "";
              try {
                actPhotoUrl = await fetchUnsplashPhoto(`${act.name} ${input.destination}`);
              } catch (e) {
                console.warn(`[Orchestrator] Failed to fetch photo for activity "${act.name}":`, e);
                actPhotoUrl = "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&auto=format&fit=crop";
              }
              return {
                ...act,
                photoUrl: actPhotoUrl,
              };
            })
          );
          return {
            ...day,
            activities: activitiesWithPhotos,
          };
        })
      );
    } catch (err) {
      console.warn("[Orchestrator] General error in outer photo activities mapping, relying on default fallbacks:", err);
    }

    // Map consolidated data to standard multi-agent response structure
    const result: ItineraryResult = {
      destinationInfo: finalData.destinationInfo,
      budgetSummary: finalData.budgetSummary,
      days: daysWithPhotos,
      weatherForecast: {
        locationName: liveWeather?.locationName || finalData.destinationInfo?.destination || input.destination,
        days: finalData.weatherAgentDays || [],
      },
      packingChecklist: (finalData.packingChecklist || []).map((p: any) => ({
        ...p,
        checked: false, // Set default unchecked state for interactive checkable list
      })),
      bestPhotoSpots: finalData.bestPhotoSpots || [],
      localLanguageInfo: finalData.localLanguageInfo || {
        languageName: "English",
        currencyCode: "USD",
        currencySymbol: "$",
        approxConversionRate: "N/A",
        phrases: [],
      },
      safetyEmergencyInfo: finalData.safetyEmergencyInfo || {
        nearestHospitalGuidance: "General local hospital",
        emergencyNumbers: { police: "911", ambulance: "911", fire: "911" },
        embassyConsulateInfo: "Not required",
        destinationSafetyTips: [],
      },
      agentLogs: {
        placesAgent: {
          thought: finalData.placesAgentThought,
          suggestedPlaces: finalData.placesAgentSuggestedPlaces,
          mcpLogs: mcpLogs,
        },
        budgetAgent: {
          thought: finalData.budgetAgentThought,
          allocations: finalData.budgetAgentAllocations,
        },
        weatherAgent: {
          thought: finalData.weatherAgentThought,
          forecastSummary: finalData.weatherAgentForecastSummary,
        },
        coordinatorAgent: {
          thought: finalData.coordinatorThought,
          planSummary: `Successfully consolidated ${input.days}-day tour with ${finalData.placesAgentSuggestedPlaces?.length || 0} attractions, adjusted dynamically to forecasted conditions.`,
        },
      },
    };

    console.log(`[Orchestrator] Optimized Multi-Agent flow completed successfully in 1 API call!`);
    return result;
  } catch (error: any) {
    console.error("[Orchestrator Error]:", error);

    // Map 429 and rate-limiting errors to standard message
    const isRateLimit =
      error?.status === 429 ||
      (error?.message &&
        (error.message.includes("429") ||
          error.message.toLowerCase().includes("quota") ||
          error.message.toLowerCase().includes("rate limit") ||
          error.message.includes("RESOURCE_EXHAUSTED")));

    if (isRateLimit) {
      throw new Error("Daily API limit reached, please try again later.");
    }
    throw error;
  }
}
